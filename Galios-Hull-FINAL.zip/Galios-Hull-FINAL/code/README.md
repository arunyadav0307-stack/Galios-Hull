# Computational Programs

Every program here is a **pure standard-library Python 3** script. No `numpy`, no
`galois`, no third-party finite-field package — the field arithmetic, polynomial
factorisation, duals, nullspaces, and Ranks are all built from scratch so that the
checks do not depend on someone else's implementation of the very thing being tested.

Verified working on **Python 3.11** and **Python 3.13**.

Run everything at once from the package root:

```bash
bash tools/run_all_validations.sh
```

---

## What these programs are, and what they are not

They are **finite computational validation**. Each one constructs a specific small
instance, then computes the quantities in Section 10 of the manuscript by **two or more
mathematically independent routes** and checks that the routes agree.

They are **not** proofs. Agreement on $\mathbb F_4$, $\mathbb F_8$, $\mathbb F_{16}$ and
the $\mathbb F_4\times\mathbb F_{16}$ bridge supports the general statements in the
manuscript; it does not establish them. The general proofs are in
`manuscript/main.tex` and `blueprint/new-paper-blueprint.md`.

The design principle throughout is **route separation**: never verify a formula by
evaluating the formula. Concretely, the programs contrast

- *direct* construction of duals from the defining pairing equations
  ($\langle c,y\rangle=0$) versus the *reciprocal* generator predicted by the theorem;
- *direct* hull computation by nullspace intersection versus the *orbit-boundary*
  statistic $b_O$ versus the *transfer-matrix* trace;
- *Gram-matrix rank* versus *dimension counting* for hull dimensions;
- *component-wise* computation versus the *global product* over the affine algebra.

If a claim in the manuscript were wrong, at least one of these pairs would disagree.

---

## The programs

### Validators — these support the main theorem

| Program | Instance | Selections | What it checks |
|---|---|---|---|
| `validate_global_product.py` | $A=\mathbb F_4\times\mathbb F_{16}$ over $\mathbb F_4$, $n=5$, $\lambda=(\omega,1)$, $k=1$ | $2^3\cdot2^5=256$ | **The mixed-component bridge.** Product-algebra laws and pairing; direct global dual vs. principal reciprocal per component; 256 distinct global code spaces; 256 global dual checks; 256 global $\mathbb F_4$ dimension/hull checks; 1 280 affine-product shift checks; the three histogram equalities; uniform mean 3 and variance 2. |
| `validate_pilot.py` | $q=4$, $n=5$, $\lambda=1$, $k=1$, four labeled $\mathbb F_4$ components | $8^4=4096$ | Factor action, direct duals, component/ring hull enumerators, orbit-polynomial identity for $a=1,\dots,5$. |
| `validate_long_orbit_examples.py` | $\mathbb F_8$: $q=8$, $n=7$, $\lambda=1$, $k=1$, orbit lengths $[1,6]$; $\mathbb F_{16}$: $q=4$, $n=5$, $k=1$, orbit lengths $[1,4]$ | $128$ and $32$ | Long cycles (length 6 and 4) where the reciprocal is genuinely non-involutory; direct duals, orbit boundary, transfer matrix, histograms. |
| `validate_nontrivial_constacyclic.py` | $q=4$, $n=5$, $\lambda=\omega$, $k=1$, orbit lengths $[1,2]$ | $2^3=8$ | A **compatible non-trivial twist**, i.e. $\lambda\neq1$ with $\lambda^{1+p^{d_s-k}}=1$. Factorisation, direct dual, hull boundary, transfer comparison. |
| `validate_n2_extension_convention.py` | N2-A over $\mathbb F_{16}$ | $32$ | Independent comparison of the direct, principal, and alternative reciprocal conventions for every selection. |

### Diagnostics — deliberately outside the main theorem

These are labelled **DIAGNOSTIC ONLY** in `validation/VALIDATION_REPORT.md`. They explore
behaviour when the compatibility condition **fails**. They deliberately do **not** run a
transfer enumeration, because the compatible-twist product is not asserted there.

| Program | Instance | Selections | What it does |
|---|---|---|---|
| `diagnose_incompatible_twist.py` | $\mathbb F_4$, $k=0$, incompatible twist | — | Direct $\sigma$ computation; no transfer enumeration. |
| `diagnose_n2_incompatible_twist.py` | N2-B over $\mathbb F_{16}$, incompatible extension twist | $8$ | Distinguishes $\sigma$ from $\rho$, exhibits both reciprocal candidates and both candidate twists, and records the original-twist failures. |

**Do not cite a diagnostic run as evidence for the main theorem.** It is evidence about
what happens *outside* its hypotheses.

---

## Independent phase checks (in `validation/`)

These seven programs live in `validation/` rather than here, because two of them resolve
paths relative to their own location (`Path(__file__).parents[1]`) and their captured
outputs in `validation/*.out` were produced from those exact paths. Moving them would
break reproducibility of that evidence.

| Program | Purpose |
|---|---|
| `phase2_counterexample_search.py` | Adversarial search for counterexamples to the Phase-2 claims |
| `phase3_independent_enumerator_check.py` | Independent enumeration route, incl. all 73 rank-two planes in $\mathbb F_8^3$ |
| `phase4_convention_equivalence.py` | Convention-equivalence checks |
| `phase5_convention_counterexamples.py` | Counterexample search across conventions |
| `phase6_end_to_end_check.py` | End-to-end pipeline check |
| `search_n1_specification.py` | Documents that N1 is unspecified (see below) |
| `source_pdf_theorem_check.py` | Extracts and checks theorem statements from the prior-work PDF |

---

## Reference results you should see

From `validation/VALIDATION_REPORT.md` and the `validation/*.out` captures:

| Instance | Mean | Variance |
|---|---|---|
| $\mathbb F_4$, $k=0$ | 0.5 | 0.25 |
| $\mathbb F_8$, $k=1$ | 1.5 | 0.375 |
| $\mathbb F_{16}$, $k=1$ | 1 | 0.25 |
| $\mathbb F_4\times\mathbb F_{16}$ bridge | 3 | 2 |

The $a=2$ variance exception shows up where orbits of length two exist — that is exactly
why the manuscript keeps a separate $\sum_{a_O=2}w_O^2/4$ term instead of treating it as
a special case of the general formula.

---

## N1

`search_n1_specification.py` exists to **document that N1 cannot be validated**, not to
validate it. N1 remains:

> **`UNSPECIFIED — CANNOT VALIDATE`**

Only $q=16$, $n=15$, $32768=2^{15}$ are known. No $k$, twist, factorisation, orbit
structure, histogram, hull distribution, or numerical result has been reconstructed.
N1 is excluded from the manuscript. Do not invent it.

---

## Conventions the programs implement

So you can check them against the manuscript:

```
sigma_{s,k}(a) = a^(p^k)
rho_{s,k}(a)   = a^(p^(e*m_s - k))  = sigma_{s,k}^{-1}
pairing        = sum_i x_i * y_i^(p^k)          (code in slot 1, Frobenius in slot 2)
                 the dual is { y : <c,y>_{s,k} = 0 for all c in C }
compatibility  = lambda_s^(1 + p^(e*m_s - k)) = 1
weight         = w_O = m_s * d_O                 (F_q-weight of one orbit factor)
boundary       = b_O(eps) = sum_i eps_i (1 - eps_{i+1})
```

Note the exponent discipline: `k` is the **Frobenius iteration index** while `p^k` is the
**field exponent**. The programs keep these separate, and the manuscript's notation table
(Table 2) flags the distinction explicitly. This was a real source of confusion earlier in
the project and is deliberately documented in both places.
