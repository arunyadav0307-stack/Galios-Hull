# Phase 10F — Final Cosmetic Typesetting Cleanup Audit

## A. Starting commit

- Repository: `arunyadav0307-stack/Galios-Hull`
- Branch: `arena/01a0c9d2-galios-hull`
- Starting commit: `63fee8bb9a312b119f59c17d3febe333fe41bb43`
- Starting commit message: `Resolve final LaTeX compilation and PDF verification`
- Starting worktree: clean, local HEAD = remote HEAD
- Reconciled against the brief: the brief quoted HEAD `08ca40cc45a1a8f8eb4e5430a2f03f70a0586254`
  (`Complete Phase 10E final manuscript audit`). The branch had already advanced by one
  commit, `63fee8b`, which added the Phase-10F environment/PDF report and the three
  already-applied LaTeX repairs (`mathrsfs`, the Figure 1 `\to` fix, the missing `$`).
  Phase 10F therefore starts from `63fee8b`, and no earlier work was undone or rewritten.

## B. Ending commit

- Ending commit: `0c65b31ab9be748322c5278a21691ac6318afc92`
- Ending commit message: `Final cosmetic typesetting cleanup`
- Parent: `63fee8bb9a312b119f59c17d3febe333fe41bb43`

This commit adds the cosmetic source cleanup to `manuscript/main.tex`, the rebuilt and
verified `manuscript/main.pdf`, this audit, and the Phase-10F evidence captures. The
exact SHA above is recorded by the immediately following
`Record Phase 10F ending commit SHA` commit, whose only change is this section, so that
the history remains append-only and no commit is rewritten or amended.

## C. Compilation environment

```text
Linux e2b.local 6.1.158+ #1 SMP PREEMPT_DYNAMIC Fri Jul 17 14:31:34 UTC 2026 x86_64 GNU/Linux
Debian GNU/Linux 13 (trixie)
```

A full system TeX Live toolchain was installed into this fresh container from the Debian
repositories (`apt-get install texlive-*`). The prior Phase-10F environment report had
recorded that no system TeX was available and that a user-local Tectonic fallback was
used; that limitation does not apply here, so pdfTeX, BibTeX, XeTeX and LuaTeX are all
genuine system installations. No Tectonic was used in this phase.

| Tool | Version | Package |
| --- | --- | --- |
| `pdflatex` (primary engine) | pdfTeX 3.141592653-2.6-1.40.26 (TeX Live 2025/dev/Debian) | texlive-latex-base 2024.20250309-1 |
| `bibtex` | BibTeX 0.99d (TeX Live 2025/dev/Debian) | texlive-bibtex-extra 2024.20250309-2 |
| `xelatex` (cross-check) | XeTeX 3.141592653-2.6-0.999996 | texlive-xetex 2024.20250309-1 |
| `lualatex` (cross-check) | LuaHBTeX 1.18.0 | texlive-latex-base |
| PDF inspection | poppler-utils 25.03.0-5+deb13u4, PyMuPDF 1.28.2 | — |

`\documentclass[11pt]{article}` is a pdfLaTeX-native class and is compiled here with
pdfTeX as the primary engine. XeTeX and LuaTeX were run as portability cross-checks.

## D. Final build commands and page count

Stale auxiliary files (`*.aux *.log *.bbl *.blg *.out *.toc *.pdf`) were deleted first.

```text
pdflatex -interaction=nonstopmode -halt-on-error main.tex   # pass 1   exit 0
bibtex main                                                 # exit 0
pdflatex -interaction=nonstopmode -halt-on-error main.tex   # pass 2   exit 0
pdflatex -interaction=nonstopmode -halt-on-error main.tex   # pass 3   exit 0
pdflatex -interaction=nonstopmode -halt-on-error main.tex   # pass 4   exit 0
```

- **Final page count: 19 pages** (US letter, 612 × 792 pt, PDF 1.7).
- Pass 3 and pass 4 produce the same page count, the same output size
  (478 856 bytes) and identical warning-free logs, confirming convergence.
- Notes on pass counts: after `bibtex`, the first re-run still reports
  `Label(s) may have changed`; pass 3 resolves it and pass 4 confirms stability. Pages
  moved 18 → 19 relative to the pre-cleanup build because Table 3's cells now wrap
  (see Section F.3) instead of overrunning the margin.
- Final PDF: `manuscript/main.pdf`
  - SHA-256 `a4cbae942887235f5d5f288535d74170c9ea3b562652283569433cf581b43397`
  - 478 856 bytes
- Final sources:
  - `manuscript/main.tex` SHA-256 `b5c038f5540960a1683cc3cb97d574dcaccb178fa86821e4a29f70ce82581fdd`
  - `manuscript/references.bib` SHA-256 `acc788ee15a476e163a4142d8ba081aaa0634543583df07a9afd035d186765cd`

**The committed PDF was verified to correspond to the committed source.** The full build
was re-run from scratch in a pristine directory; the two PDFs have the same page count
(19), the same byte size (478 856, delta 0) and a byte-identical `pdftotext -layout`
extraction. They differ only in the three timestamp-derived PDF-internal fields that
pdfTeX regenerates on every run (`CreationDate`, `ModDate`, `/ID`). See
`phase10f_reproducibility.out`.

## E. Baseline measured before any change

The unmodified starting source was compiled in a scratch copy to obtain the true
pre-cleanup warning profile (see `phase10f_baseline_warnings.out`).

- Result: 18 pages, exit 0, no errors.
- **8 overfull `\hbox` warnings**, at six distinct magnitudes:

  | Magnitude | Location |
  | --- | --- |
  | `44.68607pt` | the `K(C(J)) / H_k(C(J))` display, Theorem 8.1 (source line 719) |
  | `31.09875pt` | Table 3 rows (×2) |
  | `22.59875pt` | Table 3 row |
  | `14.09875pt` | Table 3 rows (×2) |
  | `11.68959pt` | Table 3 row |
  | `1.02878pt` | Table 3 as a whole |

  So the worst single offending box was the 44.69pt display, and the worst table row
  overran by 31.10pt.
- **28 underfull `\hbox` warnings** inside Table 3 and Table 4, mostly at
  `badness 10000`, from inter-word stretching in narrow `p{}` cells.
- **2 `hyperref` warnings**, “Token not allowed in a PDF string (Unicode)”, from the `$k$`
  in the Section 4 heading.
- XeTeX additionally reported `inputenc package ignored with utf8 based engines`.

## F. Fixes applied

All changes are confined to `manuscript/main.tex`. Full diff is 29 insertions /
16 deletions across 8 hunks. No mathematical content was touched (Section H).

### F.1 `inputenc` under Unicode engines — fixed safely

**Diagnosis.** `\usepackage[utf8]{inputenc}` is a documented no-op on XeTeX and LuaTeX
and warns `inputenc package ignored with utf8 based engines`. Under pdfLaTeX it is
harmless (and redundant on LaTeX ≥ 2018, where UTF-8 is the default). Removing it
outright would have been safe for current kernels but would break pre-2018 pdfLaTeX.

**Fix.** Guarded the two encoding packages with `iftex`, which is present in both the
TeX Live and the `\LaTeX` kernel distributions:

```latex
\usepackage{iftex}
\ifPDFTeX
  \usepackage[T1]{fontenc}
  \usepackage[utf8]{inputenc}
\fi
```

**Result.** The pdfLaTeX build is unchanged, while the warning is eliminated on the
Unicode engines. This satisfies the brief's preference to remove it without breaking
compatibility, rather than merely documenting it.

### F.2 `hyperref` PDF-string warning — fixed

**Diagnosis.** Two warnings on the Section 4 heading `$k$-Galois Duality ...`, because
math is not a legal PDF bookmark string.

**Fix.** Wrapped the math in `\texorpdfstring`, preserving the visible heading exactly
and giving `hyperref` a plain-text bookmark:

- `\section{\texorpdfstring{$k$}{k}-Galois Duality for Component Constacyclic Codes}`
- the same treatment applied to the title, which carried the identical latent issue.

The section was **not** renamed. The heading still renders as `4  k-Galois Duality for
Component Constacyclic Codes`, with `k` in math italic.

### F.3 Table layout — fixed without changing any data

**Diagnosis.** Table 3 (`tab:computations`) and Table 4 (`tab:scope`) used narrow
`p{}` columns, which fully justify and therefore stretch inter-word spaces to badness
10000. Table 3's fixed-width cells also forced long `\texttt{}` filenames to overrun.

**Fixes.**

1. Added a ragged-right column type and applied it to Tables 1, 3 and 4:
   ```latex
   \newcolumntype{L}[1]{>{\raggedright\arraybackslash}p{#1}}
   ```
2. Rebalanced Table 3's column widths
   (`0.18/0.27/0.10/0.10/0.25` → `0.15/0.23/0.11/0.13/0.23`) so the unbreakable word
   `Direct/principal` fits and no row overruns.
3. Inserted `\allowbreak` after each `\_` and before each `.py` in the Table 3 Evidence
   column, so filenames such as `validate_long_orbit_examples.py` wrap at underscores
   instead of running past the margin.

Every table cell string, number, case name and citation key is **unchanged**. Exactly
four tables remain; no table was added or removed. The visible difference is wrapping
only — and in fact the filenames are now *fully* readable, where previously they
overran the text block.

### F.4 One overfull display — fixed

**Diagnosis.** In Theorem 8.1, the two definitions of `K(C(J))` and `H_k(C(J))` were
placed side by side with `\qquad` and overran the line by 44.69pt (the single worst
box in the document, and visibly protruding ~43.6pt into the right margin in the
pre-cleanup PDF).

**Fix.** Wrapped the two statements in `\begin{gathered}...\end{gathered}` with an
explicit `\\`, so they stack vertically. The two statements themselves are preserved
character-for-character; only the separator changed. Measured effect: right-margin
protrusion on that page fell from 43.56pt to 1.08pt (the uniform baseline offset, F.5).

### F.5 Deliberately NOT changed

- **Uniform ~1.4–1.8pt right offset on every page.** Measured `\textwidth` is
  `469.75502pt`, so the true text block right edge is `72 + 469.75502 = 541.755pt`, not
  the nominal 540pt. Ink stops at 541.80pt — a residual of **0.045pt (0.016 mm)**. This
  offset is identical on the baseline and the final PDF, and generates no Overfull
  warning. It is a property of `geometry`'s `margin=1in` and is not a defect; changing
  the geometry would alter the whole document's pagination for no visible gain.
- **Bottom ink at y ≈ 750pt** is the page number (`\footskip = 30pt`), which legitimately
  occupies the bottom margin.
- **Figures.** All five placeholders retained verbatim; no figure created, generated or
  removed. Only captions, labels and float placement were reviewed, and all are correct.
- **`references.bib` untouched** — see Section I.

## G. Remaining warnings after cleanup

Warning lines per build pass, final source:

| Pass | Warning/error lines | Notes |
| --- | --- | --- |
| 1 | 43 | Expected first-run resolver messages: citations and `\ref`s undefined before `main.aux`/`main.bbl` exist |
| 2 | 26 | Expected residual resolver messages plus the `Label(s) may have changed` rerun notice |
| **3** | **0** | **Converged: no warnings of any kind** |
| **4** | **0** | **Confirmed stable** |

### Classification

- **Fatal:** none. Zero compilation errors on all four passes and on all three engines.
- **Important:** none. No warning remains that visibly damages the manuscript.
- **Cosmetic:** one, environment-only —
  `Error in luaotfload: reverting to OT1`, emitted by LuaTeX in this container.
  A control experiment compiling a one-line
  `\documentclass{article}...\end{document}` document reproduces the message
  **before `\documentclass` is even read**, proving it is produced by the engine's
  font-loader bootstrap, not by the manuscript. The cause is a missing
  `luaotfload-main.lua` in this Debian packaging. It does not occur under pdfLaTeX or
  XeTeX, which build the manuscript with zero warnings. It is **not** a manuscript defect.

No `Overfull` or `Underfull` box warning remains under any engine. No
`hyperref` PDF-string warning remains. No `inputenc` warning remains.

### Engine matrix

| Engine | Pages | Warnings (converged) |
| --- | --- | --- |
| pdfTeX (primary) | 19 | 0 |
| XeTeX | 19 | 0 |
| LuaTeX | 19 | 1 (environmental `luaotfload`, as above) |

Page count is stable at 19 across all three engines.

## H. Mathematical freeze result

**The mathematical freeze held.** Verified mechanically (see
`phase10f_freeze_verification.out`) by parsing the committed source and the cleaned
source and comparing every category that carries mathematical meaning:

- **Inline math: 396 tokens before, 396 after — identical token sets** (0 tokens
  changed, added or removed).
- **Display math: 79 blocks before, 79 after — 0 of 79 blocks carry different
  mathematical statements.** The only structural change is the `gathered` wrapper in
  F.4, whose two statements are preserved character-for-character.
- **Environments:** theorem 3/3, lemma 8/8, proposition 12/12, corollary 6/6,
  proof 29/29, abstract 1/1 — all bodies identical. Two of the three Theorem
  environments are byte-identical; the third differs only by the line break in F.4.
- **Structure:** 12 sections, 14 subsections, 5 figures, 4 tables, 4 tabulars,
  15 labels, 14 `\cite` commands (13 distinct keys, 24 key occurrences), 29 proofs —
  all counts unchanged.

Explicitly re-checked as unchanged: the reciprocal convention; the Galois/Frobenius
convention; the hull convention; the orbit structure; the transfer matrix
`T_w(u,z)`; the generating polynomial `E(u,z)`; all dimension formulas; the mean; the
variance (including the `a = 2` short-orbit term); and the validated computational
results. No definition, theorem, lemma, proposition, corollary, formula, or convention
was altered. No new mathematical result was introduced, no result was expanded, and the
research scope was not changed.

**No mathematical issue was discovered.** The Phase-10C repair was not reopened, and
no `MATHEMATICAL ISSUE DISCOVERED — RETURN TO PHASE 10C` condition arose.

## I. Bibliography status

`manuscript/references.bib` is **unchanged**. `bibtex` reports no errors and no
warnings.

- The text contains 14 `\cite` commands (8 of them comma-separated lists), 24 key
  occurrences and **13 distinct keys**. All 13 bibliography entries are cited, and no
  key is cited that is absent from the database; `plain.bst` resolved every one.
- Source DOIs are present for 11 of the 13 entries (`debnathAffinePreprint` and
  `talbi2021` are `@misc` records without DOIs). `plain.bst` does not print DOI fields,
  which is expected behaviour for that style and not an error.
- **Five** entries still carry incomplete author metadata, detected by parsing each
  `author` field for names lacking a comma (i.e. surname-only):
  `talbi2021`, `pathakZ4`, `gao2023`, `aliabadi2026` (surname-only author lists), and
  `debnathSmall2026` (the single author `Yadav` lacks a given name).
- Verified author metadata was **not** invented, and no DOI was altered or added.

**Publisher-level metadata verification pending.**

## J. PDF inspection result

All **19 pages** of the freshly built PDF were inspected, both as rendered images and
programmatically.

Visual inspection confirmed:

- **No clipping** on any page. Confirmed at the pixel level: every page was rendered at
  200 dpi and the bounding box of all ink measured. Maximum right ink is 541.80pt
  against a true text edge of 541.755pt (0.045pt residual); minimum left ink 71.64pt
  against 72pt (glyph side bearing). No content lies outside the text block.
- **No broken equations.** All displays, `aligned`/`gathered` blocks, `pmatrix`,
  `boxed` formulas and `\bigl/\Bigr` delimiters render correctly.
- **No malformed theorem environments.** `Corollary 9.1` … `9.6`, `Proposition 3.7`,
  `Theorem 8.1`, `Lemma 3.3/3.5/3.6` all present, correctly numbered and correctly
  referenced.
- **No broken references.** All 15 labels resolve; `\ref` and `\cite` links are live
  and correct; Figure 1–5 and Table 1–4 all cross-reference correctly.
- **Tables readable.** All four tables render fully inside the margins, with headers,
  rules and all data visible. The previously overrunning Table 3 Evidence column now
  wraps cleanly and is fully legible.
- **Figure placeholders correctly positioned.** All five retained, correctly captioned,
  labelled and numbered (Figure 1 workflow, 2 decomposition, 3 orbit, 4 transfer
  matrix, 5 local-to-global), each placed sensibly near its first reference.
- **Bibliography readable.** 13 entries, continuous numbering, consistent style, no
  truncated fields.
- **Page breaks reasonable.** No orphaned headings, no single-line widows, no stranded
  captions, no half-empty page except the natural end of the bibliography on page 19.
- **Title, abstract, sections correctly rendered.** Title and abstract on page 1 with
  the joint generating polynomial display; all 12 sections and the References present;
  the Section 4 heading renders as `k-Galois Duality ...` with `k` in math italic.

**No clipping was observed in the inspected PDF.** The two genuine pre-cleanup
overflows (43.56pt on page 13, 32.04pt on page 16) are measurably gone.

## K. N1 status

**N1 remains `UNSPECIFIED — CANNOT VALIDATE`.** Unchanged.

Only `q = 16`, `n = 15`, `32768 = 2^15` are known. No `k`, twist, factorization, orbit
structure, histogram, hull distribution or numerical result was invented, inferred or
added. N1 remains excluded as a computational case, and Table 4 still records its
status as `Excluded` with the boundary `Specification and expected output are
incomplete.`

## L. Verdict

**FINAL PDF VERIFIED — COSMETIC CLEANUP COMPLETE**

Justification: the manuscript now compiles with **zero warnings of any kind** on every
converged pass under pdfLaTeX and under XeTeX, produces a 19-page PDF, and passes a
pixel-level clipping inspection on all 19 pages. The single remaining message is an
environment-only LuaTeX font-loader bootstrap notice that is reproducible on a
one-line control document and therefore not attributable to the manuscript. No
fatal, important or manuscript-attributable cosmetic warning remains. The
mathematical freeze held and N1 is unchanged.

## M. Evidence files

| File | Contents |
| --- | --- |
| `validation/phase10f_baseline_warnings.out` | Pre-cleanup warning inventory from `63fee8b` |
| `validation/phase10f_final_warnings.out` | Post-cleanup warning inventory, all four passes |
| `validation/phase10f_final_build_transcript.out` | Clean-room build commands and results |
| `validation/phase10f_final_build_pass4.log` | Full converged pass-4 log |
| `validation/phase10f_engine_matrix.out` | pdfTeX / XeTeX / LuaTeX results and before-after comparison |
| `validation/phase10f_freeze_verification.out` | Machine-checked mathematical-freeze proof |
| `validation/phase10f_pdf_geometry_check.out` | Ink-based clipping measurement, all 19 pages |
| `validation/phase10f_reproducibility.out` | Clean-room rebuild cross-check against the committed PDF |
| `manuscript/main.pdf` | The final verified 19-page PDF |
