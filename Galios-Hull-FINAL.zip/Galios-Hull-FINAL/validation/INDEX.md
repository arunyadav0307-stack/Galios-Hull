# Validation & Audit Index

Everything in this folder is the project's evidence trail. It is kept for
reproducibility and provenance. **Most of it should not be sent to a journal** — see
`../SUBMISSION_CHECKLIST.md` §3.

Three things to know first:

1. **Computational results are finite validations, not proofs.** The proofs are in
   `../manuscript/main.tex` and `../blueprint/new-paper-blueprint.md`.
2. **`PHASE10B_REFEREE_REPORT.md` is internal adversarial role-play**, written by the
   project to attack its own manuscript. It is not a real referee report.
3. **N1 is `UNSPECIFIED — CANNOT VALIDATE`** and is excluded from the manuscript. Do not
   reconstruct it.

---

## A. Read these first

| File | What it is |
|---|---|
| `VALIDATION_REPORT.md` | The evidence report: environment, pass/fail table for all six validators, full captured outputs, and the limitations of each |
| `PHASE10F_FINAL_COSMETIC_TYPESETTING_AUDIT.md` | The final audit: starting/ending commit, toolchain, fixes, remaining warnings, PDF inspection, freeze result, N1 status |

## B. The final typesetting phase (10F) — evidence captures

These are the raw captures behind the Phase-10F audit. All are reproducible now that a
real LaTeX toolchain is available; see `../tools/build_pdf.sh`.

| File | What it shows |
|---|---|
| `phase10f_baseline_warnings.out` | Warning profile of the source *before* cleanup: 18 pages, 8 overfull, 28 underfull, 2 hyperref warnings |
| `phase10f_final_warnings.out` | Warning profile *after* cleanup, per pass |
| `phase10f_final_build_transcript.out` | The exact clean-room build sequence and results |
| `phase10f_final_build_pass4.log` | Full converged pass-4 log — **0 warnings** |
| `phase10f_engine_matrix.out` | pdfLaTeX / XeTeX / LuaTeX comparison, plus before-vs-after |
| `phase10f_freeze_verification.out` | **Machine-checked proof that no mathematics changed**: 396 inline-math tokens identical, 0 of 79 display blocks differ |
| `phase10f_pdf_geometry_check.out` | Pixel-level ink measurement on all 19 pages — the no-clipping test |
| `phase10f_reproducibility.out` | Clean-room rebuild vs. committed PDF: same 19 pages, same byte size, byte-identical text extraction |

## C. Phase audits, in order

| File | Phase | Outcome |
|---|---|---|
| `PHASE2_PROOF_AUDIT.md` | 2 | Theorem-by-theorem proof audit; established the proof-status ledger |
| `PHASE3_ADVERSARIAL_AUDIT.md` | 3 | Adversarial attack on the proofs |
| `PHASE4_LITERATURE_CONVENTION_AUDIT.md` | 4 | Literature and convention audit |
| `PHASE5_CONVENTION_INVARIANCE_AUDIT.md` | 5 | Convention invariance and counterexample search |
| `PHASE6_FINAL_CONSOLIDATION_AUDIT.md` | 6 | Consolidation |
| `PHASE7_FINAL_LITERATURE_AND_MANUSCRIPT_AUDIT.md` | 7 | Literature + manuscript closure |
| `PHASE8_LITERATURE_GAP_AND_NOVELTY_AUDIT.md` | 8 | Novelty stress test → `READY WITH NARROWED CONTRIBUTION CLAIMS` |
| `PHASE9_MANUSCRIPT_ARCHITECTURE_AUDIT.md` | 9 | Architecture frozen (12 sections + references) |
| `PHASE9_REVIEWER_OBJECTIONS.md` | 9 | Anticipated reviewer objections |
| `PHASE10A_MANUSCRIPT_DRAFT_AUDIT.md` | 10A | First complete draft audit |
| `PHASE10B_REFEREE_REPORT.md` | 10B | **Internal** adversarial referee simulation — found the missing *global* product pairing |
| `PHASE10C_GLOBAL_PRODUCT_REPAIR_AUDIT.md` | 10C | **The major mathematical repair.** Global affine-product pairing, dual and hull decomposition. **Mathematically frozen from here.** |
| `PHASE10D_TYPESETTING_PUBLICATION_AUDIT.md` | 10D | Source-level typesetting audit |
| `PHASE10E_FINAL_LATEX_PDF_AUDIT.md` | 10E | Final manuscript audit |
| `PHASE10F_ENVIRONMENT_BLOCKER.md` | 10F | Records that no TeX toolchain was available at that time (superseded) |
| `PHASE10F_FINAL_LATEX_ENVIRONMENT_AND_PDF_REPORT.md` | 10F | The build that first succeeded with a real TeX toolchain |
| `PHASE10F_FINAL_COSMETIC_TYPESETTING_AUDIT.md` | 10F | **Final state** — cosmetic cleanup, 19 pages, 0 warnings |

## D. Literature, novelty, and contribution boundaries

| File | What it contains |
|---|---|
| `FINAL_REFERENCE_AUDIT.md` | Reference status; separates the accessible preprint from the final publisher record |
| `LITERATURE_CLAIM_LEDGER.md` | Claim-by-claim ledger against the literature |
| `LITERATURE_TRANSFER_MATRIX.md` | Which neighbouring result transfers to which hypothesis |
| `NOVELTY_BOUNDARY.md` | What may and may not be claimed |
| `CONTRIBUTION_BOUNDARY.md` | The narrowed, hypothesis-dependent contribution statement |
| `CENTRAL_RESULT_COMPARISON.md` | Comparison against the closest prior results |

## E. Manuscript drafting controls

| File | What it contains |
|---|---|
| `MANUSCRIPT_DRAFT_SPECIFICATION.md` | The specification the draft was written to |
| `MANUSCRIPT_SECTION_ARCHITECTURE.md` | Frozen section structure |
| `MANUSCRIPT_ASSUMPTIONS.md` | Every standing hypothesis, collected |
| `MANUSCRIPT_CLAIM_MATRIX.md` | Which claim lives in which section and rests on which theorem |
| `MANUSCRIPT_NOTATION_AUDIT.md` | Notation consistency, incl. the $k$ vs. $p^k$ exponent distinction |
| `MANUSCRIPT_FIGURE_PLAN.md` | What each of the five placeholder figures is meant to show |
| `MANUSCRIPT_TABLE_PLAN.md` | The four tables and their data sources |
| `THEOREM_DEPENDENCY_GRAPH.md` | Which theorem depends on which |

## F. Source-capture outputs

`*.out` files are captured program outputs preserved exactly as produced. Each
`validation/*.py` program has a matching `.out`. Highlights:

| File | What it captures |
|---|---|
| `phase10a_full_validation.out` | The full sweep across $\mathbb F_4$, $\mathbb F_8$, $\mathbb F_{16}$ with per-instance means and variances |
| `phase10c_full_validation.out` | The Phase-10C global-product repair validation |
| `phase3_package_verification.out`, `phase7_root_validation.out`, `phase8_full_validation.out`, `phase9_full_validation.out` | Full package validations at each phase |
| `search_n1_specification.out` | Documents that N1 is unspecified — **evidence that N1 was not invented** |
| `source_pdf_theorem_check.out` | Theorem statements extracted from the prior-work PDF |

## G. Independent phase-check programs

| Program | Purpose |
|---|---|
| `phase2_counterexample_search.py` | Adversarial counterexample search |
| `phase3_independent_enumerator_check.py` | Independent enumeration route, incl. all 73 rank-two planes in $\mathbb F_8^3$ |
| `phase4_convention_equivalence.py` | Convention equivalence |
| `phase5_convention_counterexamples.py` | Convention counterexamples |
| `phase6_end_to_end_check.py` | End-to-end pipeline |
| `search_n1_specification.py` | N1 specification search (documents non-determinability) |
| `source_pdf_theorem_check.py` | Prior-work PDF theorem extraction |

**Why these live here and not in `../code/`:** two of them resolve paths relative to
their own location, and their `.out` captures were produced from these exact paths.
Relocating them would break reproducibility of that evidence.

**One environmental note:** `search_n1_specification.py` also greps Git history for N1
evidence. Outside a Git checkout it reports `git_search_exit_code=128` and continues
normally — it still reaches the same conclusion (`N1 status: UNSPECIFIED — CANNOT
VALIDATE`) and still exits 0. To get the Git-assisted search as well, run it inside a
clone of the repository.

---

## Reproducing any of this

```bash
bash ../tools/run_all_validations.sh     # all programs
bash ../tools/build_pdf.sh               # rebuild the PDF
```

The programs are pure standard-library Python 3. See `../code/README.md` for what each
one proves, and what it does not.
