# Blueprint

## `new-paper-blueprint.md`

The full mathematical working document behind the paper — **written before the
manuscript** and now superseded by it for anything a reader or referee sees.

It contains:

- The complete theorem set (Theorems 1–19) with a **proof-status ledger** using only
  these labels: `PROVED`, `PROVED WITH CONDITIONS`, `PARTIALLY PROVED`, `PROOF GAP`,
  `FALSE / COUNTEREXAMPLE FOUND`, `COMPUTATIONALLY VERIFIED ONLY`, `FUTURE WORK`.
- The principal conventions (code-first second-slot pairing, $\sigma_{s,k}$, $\rho_{s,k}$).
- The notation table and convention audit, including the deliberate separation of the
  Frobenius **iteration index** $k$ from the field **exponent** $p^k$. That distinction
  caused real confusion earlier in the project and is flagged explicitly in both the
  blueprint and the manuscript's Table 2.
- Scope statement: square-free $A=\mathbb F_q[X_1,\dots,X_\ell]/\langle t_1,\dots,t_\ell\rangle$
  with monic square-free positive-degree $t_i$, $\gcd(n,p)=1$, and compatible component
  twists.
- Positioning: an exact **labeled-code** enumerative study using factor orbits and
  transfer matrices — **not** a Burnside/Pólya equivalence-class count — with **no**
  unsupported priority claim.

## How to use it

- **To understand the mathematics in depth**, this is the most detailed single document
  in the package.
- **To read the paper**, use `../manuscript/main.pdf`. The blueprint is a working
  document: its abstract is a draft, its notation is `backtick`-quoted for editing, and
  its framing is internal.

## Do not

- Quote the blueprint's abstract as if it were the paper's abstract — the manuscript's
  abstract is the authoritative one.
- Treat a `FUTURE WORK` or `COMPUTATIONALLY VERIFIED ONLY` ledger entry as a proved
  theorem.
- Send this file to a journal. It is a pre-manuscript working document and is
  deliberately excluded from the submission core; see `../SUBMISSION_CHECKLIST.md` §3.

The blueprint is byte-identical to the tracked version in the repository
(`new-paper-blueprint.md`); only its folder location changed in this package.
