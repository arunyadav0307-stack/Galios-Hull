#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Run the complete computational validation suite.
#
# Executes every validator in code/ and every independent check in
# validation/.  The validators are pure-standard-library Python 3 programs
# and need no third-party packages.
#
# Usage:   bash tools/run_all_validations.sh
# Run from the package root.
#
# Expected result: every program exits 0.  Two programs are DIAGNOSTIC ONLY
# by design (they sit outside the compatible-twist main theorem and are not
# evidence for it) - see README.md section 6.
# ---------------------------------------------------------------------------
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

PY="${PYTHON:-python3}"
if ! command -v "$PY" >/dev/null 2>&1; then
  echo "ERROR: '$PY' not found. Set PYTHON=/path/to/python3 and retry."
  exit 1
fi

echo "== Galois-Hull computational validation suite =="
echo "root   : $ROOT"
echo "python : $($PY --version 2>&1)"
echo "date   : $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo
echo "These runs validate the listed FINITE instances only."
echo "They are not proofs of the general theorems in manuscript/main.tex."
echo

# --- primary validators -----------------------------------------------------
echo "############ A. PRIMARY VALIDATORS (code/) ############"
echo
PRIMARY=(
  validate_pilot.py
  validate_long_orbit_examples.py
  validate_nontrivial_constacyclic.py
  validate_n2_extension_convention.py
  validate_global_product.py
  diagnose_incompatible_twist.py
  diagnose_n2_incompatible_twist.py
)
fail=0
for f in "${PRIMARY[@]}"; do
  echo "-----------------------------------------------------------------"
  echo ">>> code/$f"
  echo "-----------------------------------------------------------------"
  if ( cd "$ROOT" && env -i PATH="$PATH" HOME="$HOME" LANG=C.UTF-8 LC_ALL=C \
        PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="" "$PY" "code/$f" ); then
    echo "<<< exit 0"
  else
    echo "<<< FAILED (non-zero exit)"
    fail=$((fail+1))
  fi
  echo
done

# --- independent checks -----------------------------------------------------
echo "############ B. INDEPENDENT PHASE CHECKS (validation/) ############"
echo "These cross-check the manuscript by a different route than code/."
echo
CHECKS=(
  phase2_counterexample_search.py
  phase3_independent_enumerator_check.py
  phase4_convention_equivalence.py
  phase5_convention_counterexamples.py
  phase6_end_to_end_check.py
  search_n1_specification.py
  source_pdf_theorem_check.py
)
for f in "${CHECKS[@]}"; do
  echo "-----------------------------------------------------------------"
  echo ">>> validation/$f"
  echo "-----------------------------------------------------------------"
  if ( cd "$ROOT" && env -i PATH="$PATH" HOME="$HOME" LANG=C.UTF-8 LC_ALL=C \
        PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="" "$PY" "validation/$f" ); then
    echo "<<< exit 0"
  else
    echo "<<< FAILED (non-zero exit)"
    fail=$((fail+1))
  fi
  echo
done

echo "================================================================"
if [ "$fail" -eq 0 ]; then
  echo "SUITE RESULT: all programs exited 0."
else
  echo "SUITE RESULT: $fail program(s) exited non-zero."
fi
echo
echo "Reminder:"
echo "  * diagnose_* programs are DIAGNOSTIC ONLY and prove nothing about the main theorem."
echo "  * N1 remains UNSPECIFIED - CANNOT VALIDATE; no N1 run is included."
echo "  * Captured historical outputs are in validation/*.out for comparison."
exit "$fail"
