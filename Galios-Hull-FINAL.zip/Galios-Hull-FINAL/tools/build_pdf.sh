#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Rebuild manuscript/main.pdf from manuscript/main.tex
#
# Reproduces the exact build used for the verified 19-page submission PDF:
#   pdflatex -> bibtex -> pdflatex -> pdflatex -> pdflatex
#
# Usage:   bash tools/build_pdf.sh
# Run from the package root.
# ---------------------------------------------------------------------------
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT/manuscript"

echo "== Galois-Hull manuscript build =="
echo "root    : $ROOT"
echo "workdir : $PWD"
echo

for tool in pdflatex bibtex; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "ERROR: '$tool' not found on PATH."
    echo "Install TeX Live, e.g. on Debian/Ubuntu:"
    echo "  sudo apt-get install -y texlive-latex-base texlive-latex-recommended \\"
    echo "                          texlive-fonts-recommended texlive-latex-extra \\"
    echo "                          texlive-science texlive-bibtex-extra lmodern"
    exit 1
  fi
done

echo "engine : $(pdflatex --version | head -1)"
echo "bibtex : $(bibtex --version | head -1)"
echo

echo "-- removing stale auxiliary files --"
rm -f main.aux main.bbl main.blg main.log main.out main.toc main.pdf

echo "-- pass 1 (creates main.aux) --"
pdflatex -interaction=nonstopmode -halt-on-error main.tex > build_pass1.log 2>&1
echo "   exit 0"

echo "-- bibtex --"
bibtex main > build_bibtex.log 2>&1
echo "   exit 0"

echo "-- pass 2 (reads main.bbl) --"
pdflatex -interaction=nonstopmode -halt-on-error main.tex > build_pass2.log 2>&1
echo "   exit 0"

echo "-- pass 3 (resolves cross-references) --"
pdflatex -interaction=nonstopmode -halt-on-error main.tex > build_pass3.log 2>&1
echo "   exit 0"

echo "-- pass 4 (confirms convergence) --"
pdflatex -interaction=nonstopmode -halt-on-error main.tex > build_pass4.log 2>&1
echo "   exit 0"

echo
echo "== result =="
grep "Output written" build_pass4.log || true

WARN3=$(grep -c -E 'Overfull|Underfull|Package .* Warning|LaTeX Warning|Error' build_pass3.log || true)
WARN4=$(grep -c -E 'Overfull|Underfull|Package .* Warning|LaTeX Warning|Error' build_pass4.log || true)
echo "warning lines, pass 3 : $WARN3   (expected 0)"
echo "warning lines, pass 4 : $WARN4   (expected 0)"
echo
echo "note: passes 1-2 legitimately report undefined citations/references and a"
echo "      'Label(s) may have changed' rerun notice; passes 3-4 are converged and clean."
echo
echo "expected sha256 of the verified submission PDF:"
echo "  a4cbae942887235f5d5f288535d74170c9ea3b562652283569433cf581b43397"
echo "actual sha256 of the PDF just built:"
echo "  $(sha256sum main.pdf | cut -d' ' -f1)"
echo "  (should match; only PDF-internal CreationDate/ModDate//ID may differ)"
