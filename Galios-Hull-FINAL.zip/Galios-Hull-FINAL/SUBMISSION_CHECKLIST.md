# Submission Checklist

What to upload to a journal, what to keep private, and what still needs doing before
you submit.

---

## 1. Upload these — the submission core

| File | Bytes | Notes |
|---|---|---|
| `manuscript/main.tex` | 50 635 | Complete source, 12 sections + references |
| `manuscript/references.bib` | 4 080 | 13 BibTeX records |
| `manuscript/main.pdf` | 478 856 | The compiled 19-page paper — **this is the version of record for review** |

Most journals want a **single source archive** plus a separately uploaded PDF. If asked
for one `.zip`, zip only the contents of `manuscript/` — nothing else is needed to build
the paper.

```bash
cd manuscript && zip ../manuscript-submission.zip main.tex references.bib
```

**Do not rename `main.tex` or `references.bib`** — `main.tex` contains
`\bibliography{references}`, and `tools/build_pdf.sh` assumes these names.

### Journal-specific fields you must supply yourself

- Author names, affiliations, emails, ORCID iDs
- Funding / acknowledgement text
- Cover letter
- Suggested or opposed reviewers
- MSC 2020 subject codes
  (suggested: 94B05 primary; 11T71, 13M10, 05A15 secondary — confirm against the
  journal's own list)
- Keywords — already in the manuscript: *$k$-Galois hulls; constacyclic codes;
  square-free affine algebras; exact labeled enumeration; generating polynomials;
  transfer matrices; finite-field decomposition*

---

## 2. Optionally upload — as supplementary material

Some journals invite a supplementary/appendix archive for reproducibility. If yours
does, this is a defensible bundle:

| Include | Why |
|---|---|
| `code/` (7 programs) | Every finite validation case in Section 10 |
| `validation/VALIDATION_REPORT.md` | The evidence report itself |
| `validation/*.out` | Captured outputs matching the report |
| `tools/run_all_validations.sh` | One command reproduces everything |
| `validation/INDEX.md` | Explains what each capture is |

```bash
zip -r supplementary.zip code validation/VALIDATION_REPORT.md \
    validation/INDEX.md validation/*.out tools/run_all_validations.sh
```

**Say plainly in the supplement that these are finite validations, not proofs.** The
manuscript already does; a supplementary README should repeat it.

---

## 3. Do NOT upload these

| Keep private | Reason |
|---|---|
| `validation/PHASE10B_REFEREE_REPORT.md` | Internal adversarial role-play, not a real referee report |
| `validation/PHASE*.md` (audits) | Internal audit trail; can read as self-review and may confuse a referee |
| `validation/LITERATURE_*.md`, `NOVELTY_BOUNDARY.md`, `CONTRIBUTION_BOUNDARY.md` | Strategic/positioning notes, not scholarship for publication |
| `validation/THEOREM_DEPENDENCY_GRAPH.md`, `MANUSCRIPT_*.md` | Drafting controls |
| `blueprint/new-paper-blueprint.md` | Pre-manuscript working document; superseded by the paper |
| `traceability/` | Internal commit history and diffs |
| `references/source-paper.pdf` | **Third-party copyrighted PDF.** Never redistribute as your own supplementary material |

If a journal asks you to justify a claim against prior work, cite it — do not attach it.

---

## 4. Pre-submission checks (all currently green)

- [x] Compiles with 0 errors
- [x] 0 warnings on converged passes, under pdfLaTeX and XeTeX
- [x] 19 pages
- [x] No clipping on any page (pixel-level inspection)
- [x] All cross-references and citations resolve (15 labels, 13 distinct keys)
- [x] All 13 bibliography entries are cited; no citation key is missing
- [x] 4 tables render fully inside the margins
- [x] 5 figure placeholders present, captioned, labelled, correctly numbered
- [x] No priority/novelty overclaiming in the text
- [x] N1 correctly recorded as `UNSPECIFIED — CANNOT VALIDATE` and excluded
- [x] Mathematics verified unchanged from the frozen Phase 10C state

To re-confirm the build and the computations yourself:

```bash
bash tools/build_pdf.sh
bash tools/run_all_validations.sh
```

---

## 5. Outstanding items before you submit

### 5.1 Bibliography metadata — REQUIRED before submission

Five entries have incomplete author metadata (surname-only author lists), and two
entries are `@misc` without a DOI. **Publisher-level metadata verification is pending.**

| Key | Issue |
|---|---|
| `talbi2021` | All four authors surname-only; `@misc`, no volume/pages/DOI |
| `pathakZ4` | Both authors surname-only |
| `gao2023` | All three authors surname-only |
| `aliabadi2026` | All three authors surname-only |
| `debnathSmall2026` | Author `Yadav` has no given name |

Also worth a final check: `debnathAffinePreprint` vs `debnathAffine2026` — the
accessible preprint and the final publisher record are deliberately kept as separate
records in the source audit.

**Action:** look up each entry on the publisher's own page and fill in the missing given
names. Do **not** guess or invent them. This is a bibliographic housekeeping task; it
does not touch any mathematical content and does not require re-opening any phase.

### 5.2 Figures — a decision you must make

All five figures are **intentional placeholders**:

| Figure | Intended content |
|---|---|
| 1 | Workflow: decomposition → factor sets → orbits → boundary statistic → transfer matrix → generating polynomial |
| 2 | Square-free affine decomposition $A\cong\prod_s K_s$ and the component factor sets |
| 3 | Indexed reciprocal orbit with a binary word and marked $1\to0$ edges |
| 4 | Two-state transfer matrix and its transition weights |
| 5 | Local-to-global construction and $[u^Kz^H]$ extraction |

Placeholders are safe for review, but most journals will expect real figures at
acceptance. Drawing them is a **presentation** decision, not a mathematical one — but it
is a decision, so record it rather than doing it silently.

### 5.3 Figures and tables must stay at 5 and 4

Do not add or remove figures or tables. Do not change table data. This constraint comes
from the frozen architecture.

### 5.4 If a referee challenges a formula

The mathematics is frozen after Phase 10C. If a referee raises a genuine mathematical
objection, the correct response is to **stop and report a contradiction**, not to patch
the manuscript locally. See `README.md` §11.

---

## 6. Suggested cover-letter points

Keep these narrow and factual — they match what the manuscript actually claims:

- The paper gives an **exact joint** distribution of code dimension and code-first
  $k$-Galois hull dimension for labeled factor-selection codes over a square-free affine
  algebra, as a bivariate generating polynomial factoring over reciprocal factor orbits.
- The enumerator is represented by a **weighted two-state transfer matrix and cyclic
  trace**, so it is computable orbit by orbit.
- The **global** affine-product pairing, dual, and hull decomposition are established,
  with $\mathbb F_q$-dimension additivity.
- The **candidate-first** convention of the neighbouring literature is **not** silently
  identified with the code-first dual: the transformation
  $D_{\text{candidate}}=\sigma_{k}^{2}(D_{\text{code-first}})$ is proved, together with
  a Gram-matrix argument showing the same-code hull dimensions and LCD decisions coincide.
- Specialisations yield the total count, the two marginal distributions, the LCD count,
  the mean, and the variance including the exceptional two-cycle case.
- **No priority claim is made.** The contribution is stated under explicit hypotheses.
- All claims are **conditional**; N1 is excluded, and repeated-root and
  incompatible-twist cases are explicitly out of scope.
