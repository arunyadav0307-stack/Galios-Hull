# Literature — the comparison source paper

## `source-paper.pdf`

**Debnath, Islam, Martínez-Moro, and Prakash**, *Galois hulls of constacyclic codes over
affine algebra rings*, *Discrete Mathematics* **349** (2026), Article 114750,
DOI `10.1016/j.disc.2025.114750`.

This is the **closest structural prior work** to the manuscript in this package: it also
studies Galois hulls of constacyclic codes over an affine algebra and also uses a
finite-field component decomposition.

## How it is used — and how it is NOT used

It is present for **convention comparison only**. Specifically:

- Its accessible version places the **candidate in the opposite pairing slot** from the
  code-first convention used in this manuscript.
- The manuscript therefore **states and proves the transformation** between the two
  conventions rather than silently identifying the two duals. The result is

  $$D_{\text{candidate}}(C)=\sigma_{s,k}^{2}\bigl(D_{\text{code-first}}(C)\bigr),$$

  together with a Gram-matrix argument showing that the **same-code hull dimensions and
  LCD decisions coincide** — while the dual subspaces, hull subspaces, factor supports,
  and generator supports do **not** in general.

- The manuscript's abstract and introduction treat the accessible theorem-bearing version
  and the final publisher record as **separate records**, and keep them separate in the
  reference audit. See `../validation/FINAL_REFERENCE_AUDIT.md`.

Nothing in this package reproduces, redistributes, or claims any result from that paper.
It is included so the convention comparison in manuscript Section 4.3 can be checked
against its actual source.

---

## ⚠️ Copyright notice — do not redistribute

This is a **third-party copyrighted PDF**. It was supplied as project input material for
comparison purposes.

**Do not:**
- upload it to a journal as supplementary material,
- include it in a public repository or preprint server,
- redistribute it in any form.

If you need to reference the prior work in a submission, **cite it** — do not attach it.
`../SUBMISSION_CHECKLIST.md` §3 lists it among the files that must stay private.

---

## A caution about this file

Its filename in the original repository was
`Galios hulls of constacclic codes over affine algebra rings'.pdf` — containing
typographical errors in both *Galois* and *constacyclic*. It has been renamed to
`source-paper.pdf` here for clarity. **The content is byte-identical to the original**;
only the filename changed. No citation anywhere in the manuscript uses the original
filename — the manuscript cites the paper properly via
`debnathAffinePreprint` / `debnathAffine2026` in `references.bib`.

---

## Other prior work

Two entries in `references.bib` are `@misc` records without DOIs and carry incomplete
author metadata (`debnathAffinePreprint`, `talbi2021`), and three more have surname-only
author lists (`pathakZ4`, `gao2023`, `aliabadi2026`). **Publisher-level metadata
verification is pending** — see `../SUBMISSION_CHECKLIST.md` §5.1. No author name or DOI
was invented anywhere in this project.
