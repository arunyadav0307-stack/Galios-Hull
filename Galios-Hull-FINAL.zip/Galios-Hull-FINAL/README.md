# Exact Joint Enumeration of $k$-Galois Hull Dimensions for Labeled Constacyclic Codes over Square-Free Affine Algebras

**Submission package — final verified state (Phase 10F)**

| | |
|---|---|
| Paper | *Exact Joint Enumeration of $k$-Galois Hull Dimensions for Labeled Constacyclic Codes over Square-Free Affine Algebras* |
| Manuscript | 19 pages, compiled and visually verified |
| Status | **FINAL PDF VERIFIED — COSMETIC CLEANUP COMPLETE** |
| Source branch | `arena/01a0c9d2-galios-hull` |
| Final commit | `360c1ef9b870ca4da89ab4ff2c92ff60d1d3dbe5` |
| Mathematics | **FROZEN** — no result may be changed without re-opening Phase 10C |

---

## 1. Start here (60 seconds)

| If you want to… | Open |
|---|---|
| **Read the paper** | `manuscript/main.pdf` ← the 19-page compiled paper |
| **See the LaTeX source** | `manuscript/main.tex` |
| **See the bibliography** | `manuscript/references.bib` |
| **Rebuild the PDF** | `bash tools/build_pdf.sh` |
| **Re-run all computations** | `bash tools/run_all_validations.sh` |
| **Understand the theorems & plan** | `blueprint/new-paper-blueprint.md` |
| **See what was checked & when** | `validation/VALIDATION_REPORT.md`, then `validation/INDEX.md` |
| **Prepare a journal upload** | `SUBMISSION_CHECKLIST.md` |
| **Check file integrity** | `MANIFEST.txt` |

**The three files that matter most for submission** are `manuscript/main.tex`,
`manuscript/references.bib`, and `manuscript/main.pdf`. Everything else is supporting
evidence, provenance, or tooling.

---

## 2. What the paper is about

A linear code $C$ has a *hull* $C\cap C^\perp$ — the codewords orthogonal to the whole
code. A **$k$-Galois hull** generalises the Euclidean and Hermitian cases by putting a
Frobenius automorphism into one slot of the pairing. Hulls matter for code intersection
questions, complementary-dual (LCD) codes, automorphism problems, and conditional
quantum-code constructions.

This paper asks a counting question. Given a fixed square-free affine algebra
$A\cong\prod_s K_s$ with $K_s=\mathbb F_{q^{m_s}}$, with $\gcd(n,p)=1$ so that the
component constacyclic moduli $x^n-\lambda_s$ are simple-root, and with the compatible
twist condition holding, **how many labeled factor-selection codes are there with a
given global code dimension and a given $k$-Galois hull dimension — jointly?**

The answer is an exact bivariate generating polynomial that factors over reciprocal
factor orbits, and each orbit factor is a two-state transfer-matrix trace.

### 2.1 The main theorem (Theorem 8.1 in the manuscript)

$$C(J)=\prod_{s=1}^{N}C_s(J_s)\subseteq A^n,\qquad
\mathcal E(u,z)=\sum_{J\in\mathscr C}u^{K(C(J))}z^{H_k(C(J))}
=\prod_{s=1}^{N}\prod_{O\in\mathcal O_s}\operatorname{tr}\!\bigl(T_{w_O}(u,z)^{a_O}\bigr)$$

with the weighted two-state transfer matrix

$$T_w(u,z)=\begin{pmatrix}u^w&1\\u^wz^w&1\end{pmatrix}.$$

Here $u$ records global $\mathbb F_q$ **code dimension** and $z$ records global code-first
$\mathbb F_q$ **hull dimension**:

$$K(C(J))=\sum_{s,O,i}w_O(1-\varepsilon_{O,i}),\qquad
H_k(C(J))=\sum_{s,O,i}w_O\,\varepsilon_{O,i}(1-\varepsilon_{O,i+1}).$$

For every pair $(K,H)$, the coefficient $[u^Kz^H]\mathcal E(u,z)$ is the **number of
distinct labeled factor-selection codes** with global code dimension $K$ and hull
dimension $H$.

### 2.2 Frozen conventions (do not alter)

$$\langle x,y\rangle_{s,k}=\sum_i x_i y_i^{p^k},\qquad
\sigma_{s,k}(a)=a^{p^k},\qquad
\rho_{s,k}(a)=a^{p^{d_s-k}}=\sigma_{s,k}^{-1},\qquad d_s=e m_s.$$

- **Code-first pairing.** The code is in slot 1, the Frobenius is in slot 2.
- **Inverse-Frobenius reciprocal.** $f^{\#_{s,k}}(x)=\rho_{s,k}(f_0)^{-1}\sum_{i=0}^{r}\rho_{s,k}(f_i)x^{r-i}$.
- **Compatibility condition.** $\lambda_s^{1+p^{d_s-k}}=1$ (required for the same-factor-set product).
- **Root action.** $\alpha\mapsto\alpha^{-p^{d_s-k}}$.
- **Hull support.** $(\mathcal F_s\setminus J_s)\cap\tau_{s,k}(J_s)=\tau_{s,k}(J_s)\setminus J_s$.
- **Orbit boundary statistic.** $b_O(\varepsilon)=\sum_i\varepsilon_i(1-\varepsilon_{i+1})$, and $w_O=m_s d_O$.
- **Candidate-first comparison.** $D_{\text{candidate}}(C)=\sigma_{s,k}^2\bigl(D_{\text{code-first}}(C)\bigr)$.

The candidate-first convention appears in the neighbouring literature; it is **not
identified** with the code-first dual here. The manuscript proves the transformation
rather than silently equating the two.

### 2.3 Consequences (Section 9 of the manuscript)

| Result | Formula |
|---|---|
| One-orbit polynomial | $P_{a,w}(z)=2+\sum_{b=1}^{\lfloor a/2\rfloor}\frac{a}{b}\binom{a-1}{2b-1}z^{bw}$ |
| Total labeled codes | $\mathcal E(1,1)=2^{\sum_s|\mathcal F_s|}$ |
| Code-dimension distribution | $\mathcal E(u,1)=\prod_s\prod_{f\in\mathcal F_s}\bigl(1+u^{m_s\deg f}\bigr)$ |
| Hull-dimension distribution | $H(z)=\mathcal E(1,z)=\prod_s\prod_{O\in\mathcal O_s}P_{a_O,w_O}(z)$ |
| LCD count | $\#\{C:H_k(C)=0\}=2^{\sum_s|\mathcal O_s|}$ |
| Mean hull dimension | $\mathbb E[H_k]=\sum_{s,O:\,a_O\ge2}\dfrac{a_Ow_O}{4}$ |
| Variance | $\operatorname{Var}(H_k)=\sum_{a_O=2}\dfrac{w_O^2}{4}+\sum_{a_O\ge3}\dfrac{a_Ow_O^2}{16}$ |

The separate $a=2$ variance term is essential — it is not a rounding of the general case.

### 2.4 Scope and honest boundaries

- Enumeration is over **distinct labeled factor selections**. It is **not** a count of
  equivalence classes, isometry classes, automorphism orbits, or necklaces.
- **Square-free and simple-root only.** Repeated-root cases need a different parametrisation.
- **Compatible twists only.** If $\lambda_s^{1+p^{d_s-k}}\neq1$, the code-first dual lives
  over the transformed modulus $x^n-\lambda_s^{-p^{d_s-k}}$ and this product does not apply.
- **No priority claim.** The paper states a narrowed, hypothesis-dependent contribution.
  It does **not** claim first, first-ever, unique, state-of-the-art, or absence of prior work.
- **No quantum claim.** No distance, QECC parameter, optimality, or fault-tolerance
  conclusion follows from the hull enumerator alone.
- **Five figures are intentional placeholders.** They are captions and layout only; no
  scientific figures were fabricated.

---

## 3. Folder map

```
.
├── README.md                     <-- this file
├── SUBMISSION_CHECKLIST.md       journal-upload guide (what to send, what NOT to send)
├── MANIFEST.txt                  every file with size and SHA-256
│
├── manuscript/                   ### THE SUBMISSION CORE ###
│   ├── main.tex                  full LaTeX source (12 sections + references)
│   ├── references.bib            13 BibTeX records
│   └── main.pdf                  final verified 19-page PDF
│
├── code/                         ### COMPUTATIONAL PROGRAMS ###
│   ├── README.md                 what each program does and what it proves
│   ├── validate_pilot.py                F4 pilot
│   ├── validate_long_orbit_examples.py  F8 orbit length 6, F16 orbit length 4
│   ├── validate_nontrivial_constacyclic.py  compatible λ=ω over F4
│   ├── validate_n2_extension_convention.py  N2-A, 32 selections
│   ├── validate_global_product.py       *** the F4×F16 mixed-component bridge ***
│   ├── diagnose_incompatible_twist.py        DIAGNOSTIC ONLY
│   └── diagnose_n2_incompatible_twist.py     DIAGNOSTIC ONLY
│
├── validation/                   ### EVIDENCE & AUDIT TRAIL ###
│   ├── INDEX.md                  categorised guide to everything below
│   ├── VALIDATION_REPORT.md      the computational-evidence report
│   ├── PHASE*.md                 phase-by-phase audits (Phases 2–10F)
│   ├── *.md                      literature, novelty, notation, claim ledgers
│   ├── *.out                     captured program outputs
│   └── *.py                      independent phase-level cross-checks
│
├── blueprint/
│   └── new-paper-blueprint.md    full mathematical blueprint (theorems 1–19,
│                                 proof-status ledger, conventions, positioning)
│
├── references/                   (NOT to be confused with manuscript/references.bib)
│   ├── README.md                 what the source paper is and how it was used
│   └── source-paper.pdf          the closest prior work (Debnath–Islam–Martínez-Moro–
│                                 Prakash), used for convention comparison only
│
├── tools/
│   ├── build_pdf.sh              reproducible 4-pass LaTeX + BibTeX build
│   └── run_all_validations.sh    runs every program and reports pass/fail
│
└── traceability/
    ├── GIT_LOG.txt               complete commit history of the branch
    ├── FINAL_STATE_SHA256.txt    hashes of the frozen final state
    └── phase10f_cleanup.patch    exact diff of the final Phase-10F cleanup
```

**Why the `.py` cross-checks live in `validation/` and not in `code/`:** two of them
resolve paths relative to their own location (`Path(__file__).parents[1]`). Their
captured outputs in `validation/*.out` were produced from those exact paths, so moving
them would break reproducibility of that evidence. They are left where they were.

---

## 4. How to compile the PDF

### Prerequisites

A TeX Live installation providing `pdflatex` and `bibtex`:

```bash
# Debian / Ubuntu
sudo apt-get install -y texlive-latex-base texlive-latex-recommended \
                        texlive-fonts-recommended texlive-latex-extra \
                        texlive-science texlive-bibtex-extra lmodern poppler-utils
```

The manuscript uses only standard packages: `iftex`, `lmodern`, `amsmath`, `amssymb`,
`amsthm`, `mathtools`, `mathrsfs`, `booktabs`, `array`, `enumitem`, `geometry`,
`hyperref`, `microtype`.

### Build

```bash
bash tools/build_pdf.sh
```

This runs the exact sequence used for the verified PDF — **`pdflatex` → `bibtex` →
`pdflatex` → `pdflatex` → `pdflatex`** — after deleting stale auxiliaries. Four passes
are needed: pass 3 resolves all cross-references, pass 4 confirms convergence.

Equivalently, by hand:

```bash
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error main.tex   # pass 1
bibtex main                                                 # bibliography
pdflatex -interaction=nonstopmode -halt-on-error main.tex   # pass 2
pdflatex -interaction=nonstopmode -halt-on-error main.tex   # pass 3 (converged)
pdflatex -interaction=nonstopmode -halt-on-error main.tex   # pass 4 (confirmed)
```

### What to expect

- **19 pages**, US letter, exit code 0 on every pass.
- **Zero warnings** on the converged passes (3 and 4) under `pdflatex` **and** `xelatex`.
  This was verified in Phase 10F: no overfull boxes, no underfull boxes, no hyperref
  PDF-string warnings, no `inputenc` warning.
- Passes 1–2 legitimately report undefined citations/references and a
  `Label(s) may have changed` notice, because `main.aux` and `main.bbl` do not exist yet.
  That is normal, not an error.
- Under LuaTeX you may see `Error in luaotfload: reverting to OT1`. This is an
  environment packaging artefact, reproducible on a one-line control document before
  `\documentclass` is even read. It is **not** a manuscript defect.
- Page counts of 18 are *wrong* for this source; 18 was the pre-cleanup build before
  Table 3's cells were allowed to wrap.

---

## 5. How to run the computational validation

No third-party packages are required — the programs are pure standard-library Python 3
(verified working on Python 3.11 and 3.13).

```bash
bash tools/run_all_validations.sh
```

Every program should exit 0. The two `diagnose_*` programs are **DIAGNOSTIC ONLY** by
design: they sit deliberately outside the compatible-twist theorem and prove nothing
about it.

Individual runs, e.g.:

```bash
python3 code/validate_global_product.py
```

Captured historical outputs for comparison are in `validation/*.out`.

---

## 6. What is validated computationally — and what is not

The manuscript's Section 10 reports **independent finite validation, not proofs**. The
programs deliberately compute the same quantities by separate routes — direct
construction, direct dual/nullspace computation, Gram-matrix rank, reciprocal/support
computation, local orbit enumeration, transfer-matrix evaluation, and global product
comparison — and check that the routes agree.

### The headline result: the mixed-component bridge

| Parameter | Value |
|---|---|
| Algebra | $A=\mathbb F_4\times\mathbb F_{16}$ over $\mathbb F_4$ |
| Component degrees | $m_1=1$, $m_2=2$ |
| Length / twist / Frobenius index | $n=5$, $\lambda=(\omega,1)$, $k=1$ |
| Labeled selections | $2^3\cdot2^5=256$ |

Confirmed:

- **256** distinct global code spaces
- **256** global dual/nullspace checks
- **256** global $\mathbb F_4$ dimension/hull checks
- **1 280** affine-product shift checks
- direct histogram = component-product histogram
- direct histogram = orbit-boundary histogram
- orbit-boundary histogram = transfer histogram
- uniform mean $=3$, uniform variance $=2$

### Other validated cases

| Case | Parameters | Selections |
|---|---|---|
| F4 pilot | $q=4$, $n=5$, $\lambda=1$, $k=1$, four labeled $\mathbb F_4$ components | $8^4=4096$ |
| F8 long orbit | $q=8$, $n=7$, $\lambda=1$, $k=1$; orbit lengths $[1,6]$ | $2^7=128$ |
| F16 extension | $K=\mathbb F_{16}=\mathbb F_{4^2}$, $n=5$, $\lambda=1$, $k=1$; orbit lengths $[1,4]$ | $2^5=32$ |
| Compatible twist | $q=4$, $n=5$, $\lambda=\omega$, $k=1$; orbit lengths $[1,2]$ | $2^3=8$ |
| N2-A | extension-convention comparison | $32$ |
| N2-B | incompatible-extension diagnostic | $8$ (diagnostic only) |

The independent end-to-end validator additionally checks the convention relation,
reciprocal generators, support formulas, transfer products, injective selections,
Gram/LCD calculations, and all 73 rank-two planes in $\mathbb F_8^3$ within its scope.

### What the computations do NOT establish

- They do **not** prove the general theorems. They confirm finite instances only.
- They do **not** validate N1 (see below).
- Incompatible-twist cases are diagnostics and are **excluded** from the compatible
  transfer theorem.

---

## 7. N1 — permanently unresolved

An internal validation artefact known as **N1** remains, and must remain:

> **N1: `UNSPECIFIED — CANNOT VALIDATE`**

Only $q=16$, $n=15$, $32768=2^{15}$ are known about it. Nothing else was ever
reconstructed. Specifically, **no** $k$, twist, factorisation, orbit structure,
histogram, hull distribution, or numerical result has been invented or inferred, and N1
is excluded as a computational case from the manuscript.

If you ever see a document claiming an N1 result, it did not come from this package.

---

## 8. Contribution boundary and novelty discipline

Phase 8 ran a literature/novelty stress test. Verdict:
**`READY WITH NARROWED CONTRIBUTION CLAIMS`**.

- No verified source was found establishing a theorem identical to the complete frozen
  weighted product. That is **not** the same as proving absence, and it does **not**
  license any priority wording.
- The paper therefore claims only a **narrow, hypothesis-dependent** contribution: under
  explicit square-free, simple-root, compatible-twist, fixed-component, and
  labeled-factor hypotheses, a self-contained exact joint generating polynomial
  represented by a weighted two-state transfer matrix and cyclic trace.
- The transition statistic and transfer mechanism are presented as proved in the paper;
  the transfer-matrix mechanism itself is standard machinery, and the paper says so.
- The closest structural prior work is the affine-algebra constacyclic paper in
  `references/source-paper.pdf`. Its accessible version places the candidate in the
  opposite pairing slot; the manuscript states and proves the convention transformation
  (Section 4.3) rather than identifying the two duals.

Details: `validation/NOVELTY_BOUNDARY.md`, `validation/CONTRIBUTION_BOUNDARY.md`,
`validation/LITERATURE_CLAIM_LEDGER.md`, `validation/LITERATURE_TRANSFER_MATRIX.md`,
`validation/PHASE8_LITERATURE_GAP_AND_NOVELTY_AUDIT.md`.

**Known open item:** five bibliography entries still carry incomplete author metadata
(surname-only author lists). Publisher-level metadata verification is **pending**. No
author name or DOI was invented. See `SUBMISSION_CHECKLIST.md` §5.
---

## 9. Build and audit history

The mathematics was frozen after Phase 10C. Phases 10D–10F were typesetting and
verification only.

| Phase | What happened |
|---|---|
| 2–7 | Proof audits, adversarial audit, convention invariance, literature checks, consolidation |
| 8 | Literature/novelty stress test → `READY WITH NARROWED CONTRIBUTION CLAIMS` |
| 9 | Manuscript architecture frozen (12 sections + references) |
| 10A | First complete journal-style draft |
| 10B | Adversarial mathematical audit → found the missing **global** affine-product pairing/hull decomposition |
| 10C | **Major mathematical repair** (commit `873f970`). Pairing and hull decomposition made global. **FROZEN.** |
| 10D | Source-level typesetting/publication audit (commit `df46c16`) |
| 10E | Final manuscript audit (commit `08ca40c`) |
| 10F | Real LaTeX toolchain obtained; compilation succeeded; three genuine source bugs found and fixed (`mathrsfs` missing, Figure 1 `\to` outside math mode, a missing `$`) → commit `63fee8b` |
| **10F final** | **Cosmetic typesetting cleanup** (commit `0c65b31`) and SHA record (`360c1ef`) |

### What Phase 10F changed (and did not change)

Four cosmetic fix classes, all confined to `manuscript/main.tex`:

1. `fontenc`/`inputenc` guarded by `\ifPDFTeX` (via `iftex`) — removes the
   ignored-inputenc warning under XeTeX/LuaTeX while leaving the pdfLaTeX build unchanged.
2. `\texorpdfstring{$k$}{k}` on the title and the Section 4 heading — removes two
   hyperref PDF-string warnings. **The section was not renamed.**
3. Ragged-right `L{}` table columns, rebalanced Table 3 widths, and `\allowbreak` in the
   Table 3 evidence filenames — removes 8 overfull and 28 underfull boxes. **No cell
   content changed.**
4. `gathered` for the $K(C(J))$ / $H_k(C(J))$ display in Theorem 8.1 — removes a 44.69pt
   margin overrun. **Both statements preserved character-for-character.**

**Mathematical freeze held**, and this was verified mechanically, not asserted: 396
inline-math tokens identical before and after; **0 of 79** display blocks carry different
statements; all lemma/proposition/corollary/proof bodies byte-identical. See
`validation/phase10f_freeze_verification.out`.

### Final verification state

| Check | Result |
|---|---|
| Compilation return codes | 0 errors, all passes |
| Converged warnings (pdfLaTeX) | **0** |
| Converged warnings (XeTeX) | **0** |
| Page count | **19** |
| Clipping | None — pixel-level inspection of all 19 pages |
| Tables | 4, unchanged |
| Figures | 5 placeholders, retained |
| Mathematics | Frozen, unaltered |
| N1 | `UNSPECIFIED — CANNOT VALIDATE` |
| Reproducibility | Rebuilt PDF: same page count, same byte size, byte-identical text extraction |

Evidence: `validation/PHASE10F_FINAL_COSMETIC_TYPESETTING_AUDIT.md` plus the
`validation/phase10f_*.out` captures.

---

## 10. Verifying this package

`MANIFEST.txt` lists every file with its size and SHA-256.

```bash
# verify every file against the manifest
awk 'NF==3 && $1 ~ /^[0-9a-f]{64}$/ {print $1"  "$3}' MANIFEST.txt | sha256sum -c -
```

Hashes of the frozen essentials:

| File | SHA-256 |
|---|---|
| `manuscript/main.tex` | `b5c038f5540960a1683cc3cb97d574dcaccb178fa86821e4a29f70ce82581fdd` |
| `manuscript/references.bib` | `acc788ee15a476e163a4142d8ba081aaa0634543583df07a9afd035d186765cd` |
| `manuscript/main.pdf` | `a4cbae942887235f5d5f288535d74170c9ea3b562652283569433cf581b43397` |

### Git status at packaging time

The final two commits were **local only** when this package was assembled — pushing them
required GitHub write credentials, which were not available in the assembly environment.
The history in `traceability/GIT_LOG.txt` therefore shows two commits not yet on the
remote. This does not affect the manuscript, the PDF, or any evidence: the package
contains the complete final state either way.

---

## 11. Rules for anyone continuing this work

1. **Do not change the mathematics** — definitions, theorem statements, lemmas,
   propositions, corollaries, formulas, the reciprocal convention, the Galois convention,
   the hull convention, the orbit structure, the transfer matrix, the generating
   polynomial, the dimension formulas, the mean, the variance, or the validated results.
2. **If a genuine mathematical contradiction appears, stop and report it.** Do not
   silently repair it. The correct response is a return to Phase 10C.
3. **Do not fabricate N1.**
4. **Do not add novelty or priority claims.**
5. **Do not replace the five figure placeholders** with real or AI-generated figures
   without a scientific reason and a recorded decision.
6. **Four tables stay four tables.** Do not change the table data.
7. Typesetting-only changes are fine, provided the freeze verification still passes.

---

*Package assembled from branch `arena/01a0c9d2-galios-hull` at commit
`360c1ef9b870ca4da89ab4ff2c92ff60d1d3dbe5`. All `manuscript/`, `code/`, `validation/`,
`blueprint/` and `references/` files are byte-exact copies of their tracked versions;
only `README.md`, `SUBMISSION_CHECKLIST.md`, `MANIFEST.txt`, `validation/INDEX.md`,
`code/README.md`, `references/README.md`, and `tools/` were newly written for this
package, and `new-paper-blueprint.md` and the source-paper PDF were relocated (content
untouched). The source-paper PDF sits at `references/source-paper.pdf` because the
program `validation/source_pdf_theorem_check.py` resolves exactly that path.*
