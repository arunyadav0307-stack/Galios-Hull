# Galios-Hull — Final Paper Package (manuscript source commit 3e4f87f)

Manuscript source commit: `3e4f87fb2d87f1acbefaebed94e7f6a4c4b15f78` on branch `arena/ab8e330d-galios-hull`
(the compiled PDF/log correspond to this source; CI compile commit `22f31ed`).
This package supersedes the packages built for `ea18e8c`, `dfe1995`,
`85efaba`, and `7bdc597`.

## Main files
- `manuscript/P1_15_MANUSCRIPT_DRAFT.tex` — version of record.
  SHA-256: `362710c00998c2aed02ce9e6b561f53955da4666c2cadf9a5a087962d15832f1`
- `manuscript/P1_15_MANUSCRIPT_DRAFT.md` — synchronized Markdown companion.
  SHA-256: `2c69d90c40a9e4afbfed868a21dad5cd87f3c1ce1c7183e39a49e5c69ca2e912`
- `manuscript/P1_15_MANUSCRIPT_DRAFT.pdf` — compiled manuscript (17 pages).
  SHA-256: `db8319853b7332af63a807f28aeafd37f43116976fdfd5fd4bb39f3968787549`
- `manuscript/P1_15_MANUSCRIPT_DRAFT.log` — complete pdflatex log of the
  final pass.
- `manuscript/references.bib` — standalone BibTeX form of the 25 cited
  references. The `.tex` uses an inline `thebibliography`, so BibTeX is not
  needed to compile the source as supplied.

Author as supplied: Arun Kumar Yadav, School of Basic and Applied Sciences,
K.R. Mangalam University, Gurugram, arunyadav0307@gmail.com.

## Compilation status
Compiled successfully with pdflatex (two passes) in a GitHub Actions
(Debian/TeX Live) environment: 17 pages, no errors, no undefined
references or citations. Three unbreakable math lines that overflowed the
page in the first compiled log were split (layout only, no content change)
and the manuscript was recompiled; remaining overfull boxes are at most
about 60pt and stay within the page margins. To recompile locally:

```bash
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error P1_15_MANUSCRIPT_DRAFT.tex
pdflatex -interaction=nonstopmode -halt-on-error P1_15_MANUSCRIPT_DRAFT.tex
```

## Contents
- `code/` — validator programs and saved outputs (`validate_p1_14.py`,
  `validate_p1_20.py`, `validate_code_table.py`, `validate_audit_fixes.py`
  and their recorded outputs).
- `supporting_records/` — frozen theorem blueprint, proof records,
  independent/proof audits, correction notes, the N1/N2 integration note,
  the P1-39 references note, and the L1-closure record.
- `MANIFEST_SHA256.txt` — SHA-256 manifest for every packaged file except
  the manifest itself. Verify after extraction with
  `sha256sum -c MANIFEST_SHA256.txt` from the package root.

## Validation summary
- Example 9.4 correction checked at the \(h^\#\) exponent level:
  predecessor \(2187/2187\), successor \(27/2187\) in the GF(8) case
  (`code/validate_audit_fixes.py`).
- The ten EAQECC table rows are verified by `code/validate_code_table.py`.
- Corollary 8.5 (variance of the code dimension and zero covariance) uses
  the previously proved N1/N2 results and the exact P1-14 validation record.
- All 25 bibliography entries are cited; no citation key is unresolved.
- Finite computations are supporting evidence, not substitutes for proofs.

## Remaining blockers / status
- Visual proofreading of the compiled PDF by the author is still advised.
- Gate G1 remains DEFERRED: no novelty or priority claim is made. The 2023
  related paper has not been compared at theorem level from a lawfully read
  full text.
- Journal-submission artefacts (target journal, cover letter, declarations,
  code/data DOI, ORCID/anonymised copy if required) remain author-side items.
