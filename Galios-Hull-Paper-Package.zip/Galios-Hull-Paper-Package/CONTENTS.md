# CONTENTS — paper package

**Title:** Exact Joint Enumeration of *k*-Galois Hull Dimensions for Labeled
Constacyclic Codes over Square-Free Affine Algebras

**Package frozen:** 2026-09-25 (Phase 10F). Files inside are unchanged; only this
guide is new.

---

## 1. The paper itself

| File | Bytes | What it is |
|---|---|---|
| `manuscript/main.tex` | 50 635 | **the manuscript source** — complete, buildable LaTeX |
| `manuscript/main.pdf` | 478 856 | **the compiled paper** |
| `manuscript/references.bib` | 4 080 | **the bibliography** (BibTeX) |

Build: `pdflatex main && bibtex main && pdflatex main && pdflatex main`
(the ready-made script is `tools/build_pdf.sh`).

The manuscript uses no external figure files — it is text and tables only, so there is
no `figures/` directory. `validation/MANUSCRIPT_FIGURE_PLAN.md` is a planning document
about figures, not a figure set.

---

## 2. The programs

| File | Bytes | What it does |
|---|---|---|
| `code/validate_global_product.py` | 21 642 | checks the global joint generating polynomial against brute-force enumeration |
| `code/validate_long_orbit_examples.py` | 17 611 | checks the long-orbit worked examples |
| `code/validate_n2_extension_convention.py` | 5 608 | checks the extension-field convention at `n = 2` |
| `code/validate_nontrivial_constacyclic.py` | 7 932 | checks non-trivial constacyclic cases |
| `code/validate_pilot.py` | 12 339 | pilot run over the small parameter range |
| `code/diagnose_incompatible_twist.py` | 5 031 | diagnoses the incompatible-twist configuration |
| `code/diagnose_n2_incompatible_twist.py` | 7 760 | same, specialised to `n = 2` |
| `code/README.md` | 7 133 | how to run the programs, expected output, dependencies |

These are pure Python 3 with no third-party imports. Run any of them from `code/`;
each prints its results to stdout. The recorded outputs are under `validation/`.

---

## 3. Documentation

| File | Bytes | What it is |
|---|---|---|
| `README.md` | 21 847 | **main project README** — what the paper claims, how the package is organised, how to reproduce |
| `SUBMISSION_CHECKLIST.md` | 7 566 | the pre-submission checklist, item by item |
| `validation/INDEX.md` | 7 666 | **index to every validation artefact**, with what each one establishes |
| `validation/VALIDATION_REPORT.md` | 57 963 | the consolidated validation report |
| `MANIFEST.txt` | 12 780 | SHA-256 and size of every file in the package — 101 entries, all verified |

---

## 4. Validation evidence (`validation/`)

79 files: the phase-by-phase audit reports (Phase 2 through Phase 10F), the `.py`
scripts used for independent checks, and the `.out` transcripts of every run.

Main reports, in reading order:

- `PHASE2_PROOF_AUDIT.md` — the proof
- `PHASE3_ADVERSARIAL_AUDIT.md` — attempts to break it
- `PHASE4_LITERATURE_CONVENTION_AUDIT.md` — conventions against the literature
- `PHASE5_CONVENTION_INVARIANCE_AUDIT.md` — invariance under convention changes
- `PHASE6_FINAL_CONSOLIDATION_AUDIT.md`
- `PHASE7_FINAL_LITERATURE_AND_MANUSCRIPT_AUDIT.md`
- `PHASE8_LITERATURE_GAP_AND_NOVELTY_AUDIT.md`
- `PHASE9_MANUSCRIPT_ARCHITECTURE_AUDIT.md`
- `PHASE10A_MANUSCRIPT_DRAFT_AUDIT.md` → `PHASE10F_FINAL_LATEX_ENVIRONMENT_AND_PDF_REPORT.md`
- `CONTRIBUTION_BOUNDARY.md`, `NOVELTY_BOUNDARY.md` — what the paper does and does not
  claim
- `THEOREM_DEPENDENCY_GRAPH.md`
- `FINAL_REFERENCE_AUDIT.md`, `LITERATURE_CLAIM_LEDGER.md`

---

## 5. Reference material and tooling

| Path | What it is |
|---|---|
| `references/source-paper.pdf` | the source paper this work builds on (291 546 B) |
| `references/README.md` | why the source paper is included and how it is used |
| `tools/build_pdf.sh` | builds `main.pdf` from `main.tex` |
| `tools/run_all_validations.sh` | runs every validation script in order |
| `traceability/GIT_LOG.txt` | the git history of the package |
| `traceability/FINAL_STATE_SHA256.txt` | hashes of the frozen state |
| `traceability/phase10f_source_changes.diff` | the final source changes |
| `blueprint/new-paper-blueprint.md` | the research blueprint the paper was written from (152 972 B) |

---

## 6. Integrity

Every file listed in `MANIFEST.txt` was re-hashed after this package was assembled:
**101 of 101 match**. Verify with:

```bash
python3 - <<'EOF'
import hashlib, os, re
ok = bad = 0
for line in open('MANIFEST.txt'):
    p = line.split()
    if len(p) != 3 or not re.fullmatch(r'[0-9a-f]{64}', p[0]):
        continue
    d, s, f = p
    if os.path.exists(f) and hashlib.sha256(open(f,'rb').read()).hexdigest() == d:
        ok += 1
    else:
        bad += 1; print('MISMATCH', f)
print(f'{ok} verified, {bad} bad')
EOF
```

The `MANIFEST.txt` shipped in this package was generated for the Phase 10F freeze; the
file counts refer to that freeze and are reproduced unchanged.

---

## 7. What is not in this package

- No revision history beyond `traceability/GIT_LOG.txt`.
- No `figures/` — the paper has none.
- No third-party LaTeX class files; `main.tex` uses only standard packages
  (`amsmath`, `amssymb`, `amsthm`, `mathtools`, `booktabs`, `geometry`, …).

Separately from this paper package, the repository also holds an audit of the source
paper's Galois-hull dimension claim (`research_project/FINAL_F11_EVIDENCE_DOSSIER.zip`).
That is a different deliverable and is not part of the manuscript.
