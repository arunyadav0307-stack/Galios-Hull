# Galios-Hull — Final Paper Source Package

Integrated manuscript commit: fdcf8e781d52fd3fda6ec9a667f0d35254de2444
("P1-23: integrate approved R1, R2, unified R3/N3 into manuscript").

## Main source
- manuscript/P1_15_MANUSCRIPT_DRAFT.tex   (version of record)
  SHA-256: 37ee8b82d96926fed25add46a274db9b81beae83ff572e57d4ae180d874255f8
- manuscript/P1_15_MANUSCRIPT_DRAFT.md    (synchronized companion)
- manuscript/references.bib               (standalone BibTeX form of the 16
  bibliography entries; the .tex itself uses an inline thebibliography, so
  BibTeX is NOT needed to compile it as-is)

## Compile (on your TeX system; TeX Live / MiKTeX)
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error P1_15_MANUSCRIPT_DRAFT.tex
pdflatex -interaction=nonstopmode -halt-on-error P1_15_MANUSCRIPT_DRAFT.tex

Required: article class + geometry, amsmath, amssymb, amsthm.
No figures, no \input/\include files, no .bib needed for the .tex as-is.
IMPORTANT: this package was assembled in an environment with no LaTeX
compiler, so compilation and the rendered PDF are UNVERIFIED. After
compiling, please return the complete .log and the generated PDF for
layout/error checking before calling any PDF final.

## Status (read before submission use)
- Approved and integrated: Corollary 6.4 (R1 joint symmetry),
  Corollary 7.4 (unified R3/N3 LCD law), Corollary 7.5 (C4),
  Corollary 7.6 (R2 restricted SO/DC enumerators).
- R4 remains DEFERRED (supporting_records/P1_20..., P1_21... only).
- N1/N2 remain UNADOPTED candidates (supporting_records/
  P1_15_OPTIONAL_COROLLARIES.md); they are not results of the paper.
- Gate G1 is DEFERRED: no novelty/priority claim is established
  (see supporting_records/P1_19_L1_CLOSURE_REPORT.md).
- The author line in the .tex is still the placeholder
  "[Author names and affiliations to be inserted]" - insert the real
  names/affiliations supplied by the author; none were invented here.
- Frozen blueprint baseline: supporting_records/02_THEOREM_BLUEPRINT.md,
  SHA-256 ec2fd8d58f8d2a986314f83997d750d689f7c88e98ec8f87753ab4c9cf438cff
  (unedited; integration authority is P1_23_GAP17_CORRECTION_NOTE.md).

## Programs
code/ contains the exact validators (Python 3, standard library;
validate_p1_14.py Layer A optionally uses sympy if available) and the
saved outputs validation_p1_14_output.txt / validation_p1_20_output.txt
(both end with "ALL ... CHECKS PASSED"). Computation is supporting
evidence, not a substitute for the proofs in supporting_records/.
