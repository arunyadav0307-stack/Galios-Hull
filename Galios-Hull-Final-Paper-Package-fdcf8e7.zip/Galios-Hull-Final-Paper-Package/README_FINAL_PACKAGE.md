# Galios-Hull — Final Paper Source Package (Author-Version Refresh)

Mathematical integration commit: fdcf8e781d52fd3fda6ec9a667f0d35254de2444
("P1-23: integrate approved R1, R2, unified R3/N3 into manuscript").
Author details were inserted in the manuscript source in commit
8f2bc386798e8e431af05565007b62680637438b, using only the details supplied
by the author: Arun Kumar Yadav, School of Basic and Applied Sciences,
K.R. Mangalam University, Gurugram, arunyadav0307@gmail.com.

## Main source
- manuscript/P1_15_MANUSCRIPT_DRAFT.tex   (version of record; author-version)
  SHA-256: 6aa9630da67530f3a95b7729181f79940a99481ad68511df8d694b4dc0f695e2
- manuscript/P1_15_MANUSCRIPT_DRAFT.md    (synchronized companion)
- manuscript/references.bib               (standalone BibTeX form of the 16
  bibliography entries; the .tex itself uses an inline thebibliography, so
  BibTeX is NOT needed to compile it as-is)

## Compile (on your TeX system; TeX Live / MiKTeX)
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error P1_15_MANUSCRIPT_DRAFT.tex
pdflatex -interaction=nonstopmode -halt-on-error P1_15_MANUSCRIPT_DRAFT.tex

Required: article class + geometry, amsmath, amssymb, amsthm.
No figures, no \input/\include files, no .bib needed for the .tex as-is.
IMPORTANT: this package was assembled in an environment with no LaTeX
compiler, so compilation and the rendered PDF are UNVERIFIED and no
compiled manuscript PDF is included. After compiling, please return the
complete .log and the generated PDF for layout/error checking before
calling any PDF final.

## Status (read before submission use)
- Approved and integrated: Corollary 6.4 (R1 joint symmetry),
  Corollary 7.4 (unified R3/N3 LCD law), Corollary 7.5 (C4),
  Corollary 7.6 (R2 restricted SO/DC enumerators).
- Author placeholder has been replaced in both the .tex and synchronized
  .md using only the author-supplied details above.
- R4 remains DEFERRED (supporting_records/P1_20..., P1_21... only).
- N1/N2 remain UNADOPTED candidates (supporting_records/
  P1_15_OPTIONAL_COROLLARIES.md); they are not results of the paper.
- Gate G1 is DEFERRED: no novelty/priority claim is established
  (see supporting_records/P1_19_L1_CLOSURE_REPORT.md).
- Frozen blueprint baseline: supporting_records/02_THEOREM_BLUEPRINT.md,
  SHA-256 ec2fd8d58f8d2a986314f83997d750d689f7c88e98ec8f87753ab4c9cf438cff
  (unedited; integration authority is P1_23_GAP17_CORRECTION_NOTE.md).

## Programs
code/ contains the exact validators (Python 3, standard library;
validate_p1_14.py Layer A optionally uses sympy if available) and the
saved outputs validation_p1_14_output.txt / validation_p1_20_output.txt
(both end with "ALL ... CHECKS PASSED"). Computation is supporting
evidence, not a substitute for the proofs in supporting_records/.
