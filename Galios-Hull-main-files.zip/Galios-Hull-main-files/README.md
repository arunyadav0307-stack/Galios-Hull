# Galios-Hull — Main Research Files

This archive is the final Phase-7 handoff of the frozen code-first theorem blueprint, historical Phase-1–6 audits/captures, the final literature/reference audit, novelty boundary, manuscript specification, independent validators, and the supplied source PDF.

## Start here

1. Read **new-paper-blueprint.md** for the frozen inverse-Frobenius convention, assumptions, 19-result theorem chain, dependency order, labeled enumerator, and scope limits.
2. Read **validation/PHASE7_FINAL_LITERATURE_AND_MANUSCRIPT_AUDIT.md** for the final source checks, N1 exclusion, status table, manuscript verdict, and package plan.
3. Read **validation/MANUSCRIPT_DRAFT_SPECIFICATION.md** for the conservative abstract, introduction, literature review, theorem architecture, proof graph, reproducible examples, limitations, and conclusion policy.
4. Read **validation/FINAL_REFERENCE_AUDIT.md**, **validation/LITERATURE_CLAIM_LEDGER.md**, **validation/LITERATURE_TRANSFER_MATRIX.md**, and **validation/NOVELTY_BOUNDARY.md** for source-by-source evidence and conservative transfer/novelty classifications.
5. Read **validation/PHASE6_FINAL_CONSOLIDATION_AUDIT.md** and the preserved Phase-2–5 audits for the frozen mathematical evidence.
6. Read **validation/phase6_end_to_end_check.py**, its capture, and **validation/phase7_root_validation.out** for independent finite validation evidence.
7. The supplied source PDF is in **references/source-paper.pdf** for convention comparison only.

## Run the validation suite

The archive uses only the Python standard library. From this archive root:

```bash
env -i PATH="$PATH" HOME="$HOME" LANG=C.UTF-8 LC_ALL=C PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="" bash run_all_validations.sh
```

The suite runs the finite validators, independent enumerator and convention checks, the Phase-6 end-to-end check, the local source-PDF check, and the exhaustive internal search for the underspecified validation artifact. That artifact remains `UNSPECIFIED — CANNOT VALIDATE` and is excluded from manuscript evidence.

## Frozen convention and final status

The implementation distinguishes `sigma(a)=a^(p^k)` in the second slot from the inverse Frobenius `rho(a)=a^(p^(e*m_s-k))` used by the code-first reciprocal and dual twist `lambda^(-p^(e*m_s-k))`, under compatibility `lambda^(1+p^(e*m_s-k))=1`. The candidate-first dual is computed independently and satisfies `D_candidate(C)=sigma^2(D_code-first(C))`; dual codes and factor supports need not be equal, while the restricted Gram proof gives the same-code hull dimension and LCD decision.

The main result counts distinct labeled factor selections under square-free/simple-root compatible hypotheses. It does not claim equivalence-class counts, repeated-root results, an incompatible transfer matrix, quantum distance, or priority/novelty outcome. Burnside/Pólya and quantum extensions remain future/conditional work.

**Phase-5 status:** `PASS WITH CONDITIONS — INVARIANCE PROVED UNDER EXPLICIT CONDITIONS`.  
**Phase-7 manuscript-readiness verdict:** `NOT READY — MATERIAL GAPS REMAIN` because final/corrected literature theorem transfer and the exact novelty boundary remain unresolved.

No Git metadata is included in this archive.
