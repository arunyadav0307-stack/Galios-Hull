# Galios-Hull — Main Research Files

This archive is a compact, self-contained handoff of the blueprint, mathematical audits, source-independent validators, captured outputs, literature/convention ledger, and source PDF for the Galios-Hull project.

## Start here

1. Read **new-paper-blueprint.md** for the frozen inverse-Frobenius convention, theorem-status ledger, scope limits, literature/convention warnings, and labeled enumerator formulas.
2. Read **validation/PHASE4_LITERATURE_CONVENTION_AUDIT.md** for the exact source-convention reconciliation, theorem-transfer audit, novelty boundary, and N1 decision.
3. Read **validation/LITERATURE_CLAIM_LEDGER.md** for claim-by-claim source, status, DOI, and manuscript actions.
4. Read **validation/PHASE3_ADVERSARIAL_AUDIT.md** and **validation/PHASE2_PROOF_AUDIT.md** for the earlier hostile audit and conditional first-principles proof audit.
5. Read **validation/phase4_convention_equivalence.py** for the independent candidate-first/code-first comparison over F4, F8, and F16.
6. Read **validation/VALIDATION_REPORT.md** for preserved Phase-1/Phase-2/Phase-3 captures and the distinct Phase-4 report section.
7. The supplied source PDF is in **references/source-paper.pdf** for literature comparison only.

## Run the validation suite

The project uses only the Python standard library. From this archive root:

```bash
env -i PATH="$PATH" HOME="$HOME" LANG=C.UTF-8 LC_ALL=C PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="" bash run_all_validations.sh
```

The script runs the six existing finite validators, the Phase-2 counterexample search, the Phase-3 independent checker, the Phase-4 convention checker, and the N1 specification search. Captured outputs are in **validation/**. The F4 k=0 run is **DIAGNOSTIC ONLY**. N1 is **UNSPECIFIED — CANNOT VALIDATE** because its complete parameters and expected output are absent.

## Frozen convention

The implementation distinguishes:

- `sigma(a)=a^(p^k)` for the second-slot inner product;
- `rho(a)=a^(p^(e*m_s-k))` as the inverse Frobenius;
- the principal reciprocal using `rho`;
- the compatible dual twist `lambda^(-p^(e*m_s-k))`;
- compatibility `lambda^(1+p^(e*m_s-k))=1`.

The direct inner product is `sum_i x_i y_i^(p^k)` with the code in the first slot of the annihilator. The accessible source-preprint convention is candidate-first; its displayed rho-based reciprocal/twist requires convention conversion. The exact relation is `D_candidate-first(C)=sigma^2(D_code-first(C))`, so the conventions are not silently identified.

## Scope warning

The conditional proofs and enumerator require the explicit square-free positive-degree affine relations, simple-root length `gcd(n,p)=1` (equivalently `gcd(n,q)=1`), finite-field components, componentwise Frobenius labels, compatible twists, and labeled factor selections. Finite PASS results are evidence for listed instances only. They do not establish N1, equivalence-class counts, quantum minimum distance, or unverified literature/novelty claims. Burnside/Pólya and quantum extensions remain future/conditional work.

**Phase-4 verdict:** `VERIFY — MATERIAL LITERATURE OR CONVENTION GAPS REMAIN`.

No Git metadata is included in this archive.
