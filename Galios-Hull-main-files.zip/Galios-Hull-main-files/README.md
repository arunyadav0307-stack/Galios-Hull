# Galios-Hull — Main Research Files

This archive is a compact, self-contained handoff of the main research and validation files for the Galios-Hull project.

## Start here

1. Read **new-paper-blueprint.md** for the corrected inverse-Frobenius conventions, theorem-status ledger, scope limits, literature-audit status, and enumerator formulas.
2. Read **validation/PHASE2_PROOF_AUDIT.md** for the Phase-2 first-principles proofs for Theorems 1–19, the independent hull-support orientation derivation, exact N1 resolution, counterexample search, and conditional verdict.
3. Read **code/validate_long_orbit_examples.py** for the shared finite-field, Frobenius, reciprocal, direct-inner-product, orbit, and transfer-matrix implementation.
4. Read the other validator scripts in **code/** for the F4 pilot, compatible nontrivial-twist case, F4 diagnostic, N2-A, and N2-B.
5. Read **validation/VALIDATION_REPORT.md** for the Phase-1 evidence, Phase-2 reruns, complete stdout/stderr, comparisons, exit codes, and limitations.
6. The publisher/source PDF is in **references/source-paper.pdf** for literature comparison only.

## Run the finite validators

This project uses only the Python standard library. From this archive root:

```bash
bash run_all_validations.sh
```

The script runs the six existing validators and the Phase-2 counterexample search. The captured outputs are in **validation/**. The F4 k=0 run is **DIAGNOSTIC ONLY**; N1 remains **VERIFY BEFORE MANUSCRIPT FINALIZATION** and has no fabricated output.

## Frobenius convention

The implementation distinguishes:

- `k`: Galois/Frobenius iteration number;
- `p^k`: actual field exponent in the second-slot inner product;
- `e*m_s-k`: inverse-Frobenius iteration number;
- `p^(e*m_s-k)`: actual inverse field exponent used by the principal reciprocal.

The direct inner product is:

```text
<x,y>_k = sum_i x_i * y_i^(p^k)
```

The principal reciprocal uses the inverse-Frobenius iteration. The p^k reciprocal is retained only as an explicitly labeled alternative in the N2 comparisons.

## TeX and BibTeX status

The audited source tree currently contains a Markdown blueprint rather than a completed manuscript `.tex` source, and it does not contain a `.bib` database. The archive includes transparent notices in `tex/README.md` and `bib/README.md` rather than fabricating manuscript or bibliography files. Literature-audit records and verification categories are kept in `new-paper-blueprint.md`.

## Scope warning

The Phase-2 proofs are conditional on the explicit square-free, positive-degree, simple-root, compatible-twist, and labeled-factor-selection hypotheses. Finite validator PASS results establish only the listed finite instances. They do not replace the general proofs, and they do not establish N1, equivalence-class counts, quantum distance, or unverified literature claims.

**Phase-2 verdict:** `PASS WITH CONDITIONS`.

No Git metadata is included in this archive.
