# Galios-Hull — Phase-10A first complete manuscript draft

This archive contains the frozen code-first theorem blueprint, historical Phase-1–9 audits/captures, the first complete journal-style Phase-10A LaTeX draft, its verified bibliography, manuscript audit, all validators, and the supplied source PDF.

## Start here

1. Read **manuscript/main.tex** for the complete draft.
2. Read **manuscript/references.bib** for the cited bibliography records.
3. Read **validation/PHASE10A_MANUSCRIPT_DRAFT_AUDIT.md** for theorem, formula, assumption, notation, citation, N1, structural, and compilation-status checks.
4. Read **validation/MANUSCRIPT_SECTION_ARCHITECTURE.md**, **validation/THEOREM_DEPENDENCY_GRAPH.md**, and **validation/MANUSCRIPT_ASSUMPTIONS.md** for the frozen drafting controls.
5. Read the Phase-1–9 audits and captures for preserved evidence.
6. The supplied source PDF is in **references/source-paper.pdf** for convention comparison only.

## Draft scope

The draft uses the title **Exact Joint Enumeration of k-Galois Hull Dimensions for Labeled Constacyclic Codes over Square-Free Affine Algebras**. It states the conditional labeled joint enumerator, keeps the candidate-first/code-first transformation separate, treats the transfer matrix as standard machinery, excludes N1, and makes no priority claim. Five figures are placeholders and four tables contain only verified or symbolic data.

The environment used for this package does not provide pdflatex, bibtex, or latexmk. Structural LaTeX and citation checks pass; compilation success is not claimed.

## Run the validation suite

From this archive root:

```bash
env -i PATH="$PATH" HOME="$HOME" LANG=C.UTF-8 LC_ALL=C PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="" bash run_all_validations.sh
```

No Git metadata, submission package, cover letter, or alternate fake `.tex`/`.bib` source is included.
