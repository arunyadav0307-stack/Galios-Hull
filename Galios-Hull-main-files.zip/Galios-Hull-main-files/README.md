# Galios-Hull — Phase-8 literature-gap and novelty handoff

This archive contains the frozen code-first theorem blueprint, historical Phase-1–7 audits/captures, the Phase-8 central comparison, contribution boundary, literature-gap audit, all validators, and the supplied source PDF.

## Start here

1. Read **new-paper-blueprint.md** for the frozen inverse-Frobenius convention, assumptions, 19-result theorem chain, labeled enumerator, and scope limits.
2. Read **validation/PHASE8_LITERATURE_GAP_AND_NOVELTY_AUDIT.md** for the final Phase-8 decision and formally characterized source/novelty gaps.
3. Read **validation/CENTRAL_RESULT_COMPARISON.md** for the theorem-level source comparison.
4. Read **validation/CONTRIBUTION_BOUNDARY.md** for the only safe manuscript contribution statement.
5. Read **validation/MANUSCRIPT_DRAFT_SPECIFICATION.md**, **validation/NOVELTY_BOUNDARY.md**, **validation/LITERATURE_CLAIM_LEDGER.md**, and **validation/LITERATURE_TRANSFER_MATRIX.md** for the updated manuscript-facing and source-transfer rules.
6. Read the preserved Phase-2–7 audits and captures for the frozen mathematical and convention evidence.
7. The supplied source PDF is in **references/source-paper.pdf** for convention comparison only.

## Run the validation suite

The archive uses only the Python standard library. From this archive root:

```bash
env -i PATH="$PATH" HOME="$HOME" LANG=C.UTF-8 LC_ALL=C PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="" bash run_all_validations.sh
```

The suite runs the finite validators, independent enumerator and convention checks, the Phase-6 end-to-end check, the local source-PDF check, and the exhaustive internal search for the underspecified validation artifact. N1 remains `UNSPECIFIED — CANNOT VALIDATE` and is excluded from manuscript evidence.

## Frozen convention and Phase-8 decision

The implementation distinguishes `sigma(a)=a^(p^k)` in the second slot from the inverse Frobenius `rho(a)=a^(p^(e*m_s-k))` used by the code-first reciprocal and dual twist `lambda^(-p^(e*m_s-k))`, under compatibility `lambda^(1+p^(e*m_s-k))=1`. The candidate-first dual satisfies `D_candidate(C)=sigma_k^2(D_code-first(C))`; dual codes and factor supports need not be equal, while the restricted Gram proof gives the same-code hull dimension and LCD decision.

The main result counts distinct labeled factor selections under square-free/simple-root compatible hypotheses. Exact hull enumeration is known in several narrower families; the transfer matrix and cyclic transition statistic are standard tools. The safe Phase-8 contribution is the conditional exact weighted joint enumerator for the specified family, with no priority claim.

**Phase-5 status:** `PASS WITH CONDITIONS — INVARIANCE PROVED UNDER EXPLICIT CONDITIONS`.
**Phase-7 historical verdict:** `NOT READY — MATERIAL GAPS REMAIN`.
**Phase-8 decision:** `B. READY WITH NARROWED CONTRIBUTION CLAIMS`.

No Git metadata is included in this archive. No fake `.tex` or `.bib` source is included.
