# Galios-Hull — Main Research Files

This archive is a compact, self-contained handoff of the main research files for the Galios-Hull project.

## Start here

1. Read **new-paper-blueprint.md**. It is the current manuscript/research blueprint and contains the definitions, proof targets, scope limits, literature-audit status, computational protocol, executed-output record, and final consistency status.
2. Read **code/validate_long_orbit_examples.py** for the shared finite-field, Frobenius, reciprocal, direct-inner-product, orbit, and transfer-matrix implementation.
3. Read the other validator scripts in **code/** for the F4 pilot, compatible nontrivial-twist case, F4 diagnostic, N2-A, and N2-B.
4. Read **validation/VALIDATION_REPORT.md** for the actual clean-environment commands, dates, Python version, complete stdout/stderr, exit codes, and limitations.
5. The publisher/source PDF is in **references/source-paper.pdf** for literature comparison only.

## Run the finite validators

This project uses only the Python standard library. From this archive root:

```bash
bash run_all_validations.sh
```

The captured outputs are in **validation/**. The F4 k=0 run is **DIAGNOSTIC ONLY**; N1 remains **VERIFY BEFORE MANUSCRIPT FINALIZATION**.

## Frobenius convention

The implementation distinguishes:

- `k`: Galois/Frobenius iteration number;
- `p^k`: actual field exponent in the second-slot inner product;
- `e*m_s-k`: inverse-Frobenius iteration number;
- `p^(e*m_s-k)`: actual inverse field exponent used by the principal reciprocal.

The direct inner product is:

```text
<x,y>_k = sum_i x_i * y_i^(p^k)
```

The principal reciprocal uses the inverse-Frobenius iteration. The p^k reciprocal is retained only as an explicitly labeled alternative in the N2 comparisons.

## TeX and BibTeX status

The audited source tree currently contains a Markdown blueprint rather than a completed manuscript `.tex` source, and it does not contain a `.bib` database. The archive includes transparent notices in `tex/README.md` and `bib/README.md` rather than fabricating manuscript or bibliography files. Literature-audit records and verification categories are kept in `new-paper-blueprint.md`.

## Scope warning

Finite validator PASS results establish only the listed finite instances. They do not replace the general proofs for the affine decomposition, reciprocal formula, factor permutation, hull-support formula, orbit-boundary formula, transfer theorem, moments, LCD count, or conditional quantum applications.

No Git metadata is included in this archive.
