# Galios-Hull — Main Research Files

This archive is a compact, self-contained handoff of the Markdown blueprint, the conditional code-first theorem chain, historical Phase-1–5 audits/captures, the Phase-6 literature-transfer matrix and publication-safety audit, independent validators, the captured source-PDF check and N1 search, and the source PDF.

## Start here

1. Read **new-paper-blueprint.md** for the frozen inverse-Frobenius convention, consolidated standing assumptions, theorem dependency order, labeled enumerator, and scope limits.
2. Read **validation/PHASE6_FINAL_CONSOLIDATION_AUDIT.md** for the final theorem chain, formal convention transformation, Gram proof, literature/PDF check, N1 closure, independent end-to-end validation, and publication decision.
3. Read **validation/LITERATURE_TRANSFER_MATRIX.md** for source-by-source transfer status.
4. Read **validation/PHASE5_CONVENTION_INVARIANCE_AUDIT.md** and the preserved Phase-4, Phase-3, and Phase-2 audits for historical evidence.
5. Read **validation/phase6_end_to_end_check.py** and its capture for the independent direct-hull, support, Gram, and transfer-enumerator routes.
6. Read **validation/source_pdf_theorem_check.out** for the local source-PDF record check.
7. The supplied source PDF is in **references/source-paper.pdf** for convention comparison only.

## Run the validation suite

The archive uses only the Python standard library. From this archive root:

```bash
env -i PATH="$PATH" HOME="$HOME" LANG=C.UTF-8 LC_ALL=C PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="" bash run_all_validations.sh
```

The suite runs the prior finite validators, the Phase-2 counterexample search, the Phase-3 independent enumerator checker, the Phase-4 convention checker, the Phase-5 convention/invariance search, the independent Phase-6 end-to-end checker, the local source-PDF theorem-anchor check, and the exhaustive N1 repository/archive search. N1 intentionally remains `UNSPECIFIED — CANNOT VALIDATE`.

## Frozen convention and Phase-6 result

The implementation distinguishes `sigma(a)=a^(p^k)` in the second slot from the inverse Frobenius `rho(a)=a^(p^(e*m_s-k))` used by the code-first reciprocal and dual twist `lambda^(-p^(e*m_s-k))`, under compatibility `lambda^(1+p^(e*m_s-k))=1`. The candidate-first dual is computed independently and satisfies `D_candidate(C)=sigma^2(D_code-first(C))`; dual codes and factor supports need not be equal, while the restricted Gram proof gives the same-code hull dimension and LCD decision.

The main result counts distinct labeled factor selections under square-free/simple-root compatible hypotheses. It does not claim equivalence-class counts, repeated-root results, a two-modulus incompatible transfer matrix, quantum distance, or a priority/novelty outcome. Burnside/Pólya and quantum extensions remain future/conditional work.

**Phase-5 status:** `PASS WITH CONDITIONS — INVARIANCE PROVED UNDER EXPLICIT CONDITIONS`.  
**Phase-6 manuscript-readiness verdict:** `NOT READY — MATERIAL GAPS REMAIN` because final/corrected literature theorem transfer, exact novelty boundary, and the missing N1 artifact remain unresolved.

No Git metadata is included in this archive.
