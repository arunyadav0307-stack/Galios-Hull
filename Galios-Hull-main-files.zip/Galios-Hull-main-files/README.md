# Galios-Hull — Main Research Files

This archive is a compact, self-contained handoff of the blueprint, mathematical audits, source-independent validators, captured outputs, and source PDF for the Galios-Hull project.

## Start here

1. Read **new-paper-blueprint.md** for the frozen inverse-Frobenius convention, theorem-status ledger, scope limits, literature/convention warnings, and labeled enumerator formulas.
2. Read **validation/PHASE3_ADVERSARIAL_AUDIT.md** for the hostile 40-section manuscript-level audit and the exact Phase-3 verdict.
3. Read **validation/PHASE2_PROOF_AUDIT.md** for the conditional first-principles proofs of Theorems 1–19 and the earlier hull-support derivation.
4. Read **validation/phase3_independent_enumerator_check.py** for the independent finite-field, direct-dual, hull, orientation, injectivity, and transfer checks.
5. Read **validation/VALIDATION_REPORT.md** for preserved Phase-1/Phase-2 captures and the appended Phase-3 report section.
6. The supplied source PDF is in **references/source-paper.pdf** for literature comparison only.

## Run the validation suite

The project uses only the Python standard library. From this archive root:

```bash
env -i PATH="$PATH" HOME="$HOME" LANG=C.UTF-8 LC_ALL=C PYTHONPATH="" bash run_all_validations.sh
```

The script runs the six existing finite validators, the Phase-2 counterexample search, and the Phase-3 independent checker. Captured outputs are in **validation/**. The F4 k=0 run is **DIAGNOSTIC ONLY**. N1 is **UNSPECIFIED — CANNOT VALIDATE** because its complete parameters and expected output are absent.

## Frozen convention

The implementation distinguishes:

- `sigma(a)=a^(p^k)` for the second-slot inner product;
- `rho(a)=a^(p^(e*m_s-k))` as the inverse Frobenius;
- the principal reciprocal using `rho`;
- the compatible dual twist `lambda^(-p^(e*m_s-k))`;
- compatibility `lambda^(1+p^(e*m_s-k))=1`.

The direct inner product is `sum_i x_i y_i^(p^k)` with the code in the first slot of the annihilator. The source-preprint candidate-first convention is probed separately and is not silently identified with this convention.

## Scope warning

The conditional proofs and enumerator require the explicit square-free positive-degree affine relations, simple-root length `gcd(n,p)=1` (equivalently `gcd(n,q)=1`), finite-field components, componentwise Frobenius labels, compatible twists, and labeled factor selections. Finite PASS results are evidence for listed instances only. They do not establish N1, equivalence-class counts, quantum minimum distance, or unverified literature/novelty claims. Burnside/Pólya and quantum extensions remain future/conditional work.

**Phase-3 verdict:** `VERIFY — MATERIAL AUDIT GAPS REMAIN`.

No Git metadata is included in this archive.
