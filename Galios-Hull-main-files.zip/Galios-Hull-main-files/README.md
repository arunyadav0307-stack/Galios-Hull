# Galios-Hull — Phase-9 manuscript architecture handoff

This archive contains the frozen code-first theorem blueprint, historical Phase-1–8 audits/captures, the Phase-9 manuscript architecture and mathematical-writing audit, assumptions, notation, claim, figure, table, and reviewer controls, all validators, and the supplied source PDF.

## Start here

1. Read **validation/PHASE9_MANUSCRIPT_ARCHITECTURE_AUDIT.md** for the title audit, structured abstract, central theorem, reviewer synthesis, Q1-level logic check, and the exact Phase-9 decision.
2. Read **validation/MANUSCRIPT_SECTION_ARCHITECTURE.md** for the 13-section drafting plan.
3. Read **validation/THEOREM_DEPENDENCY_GRAPH.md** for the acyclic 19-result order and separate convention/Gram branches.
4. Read **validation/MANUSCRIPT_ASSUMPTIONS.md** and **validation/MANUSCRIPT_NOTATION_AUDIT.md** before drafting equations.
5. Read **validation/MANUSCRIPT_CLAIM_MATRIX.md** for permitted and forbidden wording.
6. Read **validation/MANUSCRIPT_FIGURE_PLAN.md**, **validation/MANUSCRIPT_TABLE_PLAN.md**, and **validation/PHASE9_REVIEWER_OBJECTIONS.md** before preparing presentation material.
7. Read **new-paper-blueprint.md**, **validation/MANUSCRIPT_DRAFT_SPECIFICATION.md**, and the Phase-1–8 audits for preserved mathematical and literature evidence.
8. The supplied source PDF is in **references/source-paper.pdf** for convention comparison only.

## Phase-9 decision and scope

**A. MANUSCRIPT ARCHITECTURE FROZEN — READY FOR DRAFTING**.

This is not a final manuscript and not a submission-readiness or journal-acceptance claim. The central result is a conditional exact joint labeled enumerator under square-free, simple-root, compatible-twist, fixed-component, and equal-degree-within-orbit hypotheses. The candidate-first/code-first transformation remains separate, N1 remains `UNSPECIFIED — CANNOT VALIDATE`, and no priority claim is made.

## Run the validation suite

The archive uses only the Python standard library. From this archive root:

```bash
env -i PATH="$PATH" HOME="$HOME" LANG=C.UTF-8 LC_ALL=C PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="" bash run_all_validations.sh
```

The suite runs the prior finite, convention, enumerator, end-to-end, source-PDF, and N1-exclusion validators. The Phase-9 capture additionally records architecture checks. No N1 numeric value, final `.tex`/`.bib` source, unsupported example, or fabricated literature claim is included.

No Git metadata is included in this archive. No fake `.tex` or `.bib` source is included.
