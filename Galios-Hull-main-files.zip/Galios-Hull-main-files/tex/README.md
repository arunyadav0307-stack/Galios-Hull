# TeX source status

The audited repository contains the Markdown blueprint and Phase-7 manuscript specification rather than a completed manuscript `.tex` source. No TeX source is fabricated in this archive.
