# TeX source status

No manuscript `.tex` source is present in the source repository at this time.

The authoritative manuscript plan is `../new-paper-blueprint.md`. It contains the current mathematical structure, proof targets, scope limitations, literature-audit classifications, computational protocol, and final consistency status.

This notice is included so that the absence of TeX source is explicit rather than silently implied.
