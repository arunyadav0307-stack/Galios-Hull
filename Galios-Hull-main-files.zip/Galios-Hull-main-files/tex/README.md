# TeX source status

The audited repository contains the Markdown blueprint rather than a completed manuscript `.tex` source. No TeX source is fabricated in this archive.
