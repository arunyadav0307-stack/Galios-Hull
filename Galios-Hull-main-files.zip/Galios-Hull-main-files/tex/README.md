No alternate LaTeX source is fabricated in this directory. The actual Phase-10A draft is manuscript/main.tex.
