No LaTeX source is fabricated in this package. The authorized manuscript-facing specification is validation/MANUSCRIPT_DRAFT_SPECIFICATION.md.
