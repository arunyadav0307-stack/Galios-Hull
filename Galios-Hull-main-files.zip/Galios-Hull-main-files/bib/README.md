No BibTeX source is fabricated in this directory. The actual Phase-10A bibliography is manuscript/references.bib.
