# BibTeX source status

No `.bib` bibliography database is present in the source repository at this time.

The literature records and their verification categories are maintained in Section 20A of `../new-paper-blueprint.md`. Records marked metadata-only, DOI-unverified, or theorem-level unresolved must not be used for exact theorem claims until directly checked.

This notice is included so that no bibliography file is fabricated.
