No BibTeX source is fabricated in this package. Add only directly verified references during a later manuscript-source phase.
