#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
python code/validate_pilot.py
python code/validate_long_orbit_examples.py
python code/validate_nontrivial_constacyclic.py
python code/diagnose_incompatible_twist.py
python code/validate_n2_extension_convention.py
python code/diagnose_n2_incompatible_twist.py
python validation/phase2_counterexample_search.py
python validation/phase3_independent_enumerator_check.py
python validation/phase4_convention_equivalence.py
python validation/search_n1_specification.py
