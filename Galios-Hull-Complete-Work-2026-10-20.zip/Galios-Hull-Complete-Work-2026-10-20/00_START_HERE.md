# COMPLETE WORK — Galois Hulls / k-Galois Hull Enumeration

**Prepared:** 2026-10-20
**Total:** 154 files across three folders

---

## What is in this archive

| Folder | Contents |
|---|---|
| `01_Paper_Package/` | The paper: manuscript source, compiled PDF, bibliography, programs, validation evidence, README, manifest |
| `02_F11_Audit/` | Independent audit of the source paper's Galois-hull dimension claim: dossier, decision document, verification log, scripts, logs |
| `03_Source_Paper/` | The source paper being audited (arXiv:2412.08512v1) |

---

## 1. The paper — `01_Paper_Package/`

**Title:** *Exact Joint Enumeration of k-Galois Hull Dimensions for Labeled Constacyclic
Codes over Square-Free Affine Algebras*

Start with `01_Paper_Package/CONTENTS.md` — it maps every file.

| Need | File |
|---|---|
| Manuscript source | `manuscript/main.tex` (50 635 B) |
| Compiled paper | `manuscript/main.pdf` (478 856 B) |
| Bibliography | `manuscript/references.bib` (4 080 B) |
| Programs | `code/` — 7 validation scripts |
| Overview | `README.md` (21 847 B) |
| Validation evidence | `validation/` — 79 files, Phase 2 → Phase 10F |
| Build scripts | `tools/build_pdf.sh`, `tools/run_all_validations.sh` |
| Integrity | `MANIFEST.txt` — 101 files, all verified |

Build the PDF with:

```bash
cd manuscript && bash ../tools/build_pdf.sh
```

The paper has **no figure files** — it is text and tables only.

---

## 2. The audit — `02_F11_Audit/`

An independent check of one claim in the source paper: whether the coefficient
`a_{S(ν)}` in the CRT decomposition lies in `F_q` or in the component field `A_{S(ν)}`.

Start with:

| File | What it is |
|---|---|
| `FINAL_F11_EVIDENCE_DOSSIER.md` | the dossier — findings, loci, evidence table |
| `FINAL_GO_NO_GO_DECISION.md` | the decision document and its rule |
| `FINAL_F11_VERIFICATION_LOG.md` | how the evidence was gathered and re-run |
| `verification/VERBATIM_LOCI_v1.md` | every decisive claim with page and verbatim text |

Programs: `code/table1_audit.py`, `code/table1_forensics.py`, `code/f11_source_audit.py`,
`code/final_check_A.py`, `code/final_check_B.py`, `code/gf.py`,
`code/isometry_hull_screening.py`.

**Decision status: BLOCKED.** The audit is complete for arXiv v1 and for all 13 rows of
the source paper's Table 1. It makes **no claim about the published version of record**,
whose `§2` body is behind a paywall and was not read. Nothing here asserts that the
published article contains an error.

Two outgoing requests accompany the audit:
`EVIDENCE_REQUEST_TO_AUTHOR.md` and `ILL_REQUEST_TO_LIBRARY.md`.

---

## 3. The source paper — `03_Source_Paper/`

`source-paper-arXiv-2412.08512v1.pdf` — 27 pp, 291 546 B,
SHA-256 `0db90bfbeda69ad1af231b81d92f24be3589ed15ac2e0ade6605ba7ad0ddc039`.

Debnath, Islam, Martínez-Moro, Prakash. The version of record is
*Discrete Mathematics* **349**(2) (2026) 114750, DOI `10.1016/j.disc.2025.114750` — not
open access, and not included here.

---

## 4. Notes

**No nested archives.** The two source archives
(`Galios-Hull-Submission-Phase10F.zip`, `FINAL_F11_EVIDENCE_DOSSIER.zip`) are not
duplicated inside this one; their contents appear here as plain files, so everything can
be read and searched directly.

**Nothing was modified** in assembling this archive. The manuscript, programs, validation
outputs and audit results are byte-identical to their frozen state; `MANIFEST.txt` was
re-run after assembly and 101 of 101 entries match.

**Git.** The repository `arunyadav0307-stack/Galios-Hull`, branch
`arena/1625045b-galios-hull`, holds the same material.
