# Galios-Hull - Final Paper Source Package (Complete, commit ea18e8c)

Manuscript lineage on branch arena/ab8e330d-galios-hull:
- fdcf8e7 "P1-23: integrate approved R1, R2, unified R3/N3 into manuscript"
- 8f2bc38 author details inserted (Arun Kumar Yadav, School of Basic and
  Applied Sciences, K.R. Mangalam University, Gurugram,
  arunyadav0307@gmail.com - only the details supplied by the author)
- 3659b6d expanded explanations of Examples 9.1-9.5
- ea18e8c (current) Section 9, Table 1: ten new verified EAQECC examples

## Main source
- manuscript/P1_15_MANUSCRIPT_DRAFT.tex   (version of record)
  SHA-256: 5a5f93f2f560fc34add49d896d5e6694e0c3e9e0ab6f64e71979478a08730a9b
- manuscript/P1_15_MANUSCRIPT_DRAFT.md    (synchronized companion)
- manuscript/references.bib               (standalone BibTeX form of the 16
  bibliography entries; the .tex itself uses an inline thebibliography, so
  BibTeX is NOT needed to compile it as-is)

## Compile (on your TeX system; TeX Live / MiKTeX)
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error P1_15_MANUSCRIPT_DRAFT.tex
pdflatex -interaction=nonstopmode -halt-on-error P1_15_MANUSCRIPT_DRAFT.tex

Required: article class + geometry, amsmath, amssymb, amsthm.
No figures, no input/include files, no .bib needed for the .tex as-is.
IMPORTANT: this package was assembled in an environment with no LaTeX
compiler, so compilation and the rendered PDF are UNVERIFIED and no
LaTeX-compiled manuscript PDF is included. After compiling, please return
the complete .log and the generated PDF for layout/error checking before
calling any PDF final.

## PDF files in this complete package
- README_FINAL_PACKAGE.pdf - PDF rendering of this README.
- manuscript/P1_15_MANUSCRIPT_DRAFT_PREVIEW_FROM_MARKDOWN.pdf - reading
  preview generated from the synchronized Markdown companion (ea18e8c).
  It is NOT a LaTeX-compiled manuscript PDF.
- manuscript/P1_15_CODE_TABLE_PREVIEW.pdf - preview rendering of the new
  Section 9 code table (Table 1) alone, for quick inspection. Also a
  preview, not a compiled paper PDF.
- Supporting report PDFs in supporting_records/ for P1_19-P1_22.

## Status (read before submission use)
- Approved and integrated: Corollary 6.4 (R1 joint symmetry),
  Corollary 7.4 (unified R3/N3 LCD law), Corollary 7.5 (C4),
  Corollary 7.6 (R2 restricted SO/DC enumerators).
- Section 9 examples 9.1-9.5 carry expanded explanations (3659b6d).
- Table 1 (ea18e8c) lists ten new finite-field codes with independently
  computed minimum distances; the EAQECC column marks EA-Singleton
  optimality only (* Delta=0, dagger Delta=2). No best-known/Grassl
  claim is made, and no distance comes from the enumerator itself.
- R4 remains DEFERRED; N1/N2 remain UNADOPTED candidates.
- Gate G1 is DEFERRED: no novelty/priority claim is established
  (see supporting_records/P1_19_L1_CLOSURE_REPORT.md).
- Frozen blueprint baseline: supporting_records/02_THEOREM_BLUEPRINT.md,
  SHA-256 ec2fd8d58f8d2a986314f83997d750d689f7c88e98ec8f87753ab4c9cf438cff
  (unedited; integration authority is P1_23_GAP17_CORRECTION_NOTE.md).

## Programs
code/ contains the exact validators (Python 3, standard library;
validate_p1_14.py Layer A optionally uses sympy if available) and saved
outputs, including validation_code_table_output.txt
("ALL 10 CODE-TABLE ROWS VERIFIED": hull by formula and Gram rank;
distance by two exact implementations plus explicit minimum-weight
codewords). Computation is supporting evidence, not a substitute for
the proofs in supporting_records/.
