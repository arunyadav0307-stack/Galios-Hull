# Galios-Hull — Final Paper Source Package (source commit 85efaba)

Source commit: `85efaba3714ad8c3bccf799563ac9adc2ff0195f` on branch `arena/ab8e330d-galios-hull`.
This is the finalization package for the current manuscript, including the
corrected Example 9.4, Example 9.6, the supplied author details, and the
integrated N1/N2 second-order corollary (Corollary 8.5). It supersedes the
packages built for `ea18e8c` and `dfe1995`.

## Main source
- `manuscript/P1_15_MANUSCRIPT_DRAFT.tex` — version of record.
  SHA-256: `08db4243f07e702c68a90aa5f84a8abf305fc5149b0b830ed65458c246b2cf9b`
- `manuscript/P1_15_MANUSCRIPT_DRAFT.md` — synchronized Markdown companion.
  SHA-256: `6f9f56de0da98c3e82676993f10ec4d725fb06822b6b2da263eda07c43bf8712`
- `manuscript/references.bib` — standalone BibTeX form of the 18 cited
  references. The `.tex` uses an inline `thebibliography`, so BibTeX is not
  needed to compile the source as supplied.

Author as supplied: Arun Kumar Yadav, School of Basic and Applied Sciences,
K.R. Mangalam University, Gurugram, arunyadav0307@gmail.com.

## Compile (author-side TeX system required)
From the extracted package root:

```bash
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error P1_15_MANUSCRIPT_DRAFT.tex
pdflatex -interaction=nonstopmode -halt-on-error P1_15_MANUSCRIPT_DRAFT.tex
```

Required packages are only the standard `article` class with `geometry`,
`amsmath`, `amssymb`, and `amsthm`.

**Compilation status:** not compiled in the preparation environment because
no TeX compiler is available. No compiled manuscript PDF and no preview PDF
is included. Compilation and visual proofreading remain pending; after
compiling, return the complete `.log` and generated `.pdf` for the
layout/error review before calling any PDF final.

## Contents
- `code/` — validator programs and saved outputs, including
  `validate_p1_14.py`, `validate_p1_20.py`, `validate_code_table.py`, and
  `validate_audit_fixes.py` with their recorded outputs.
- `supporting_records/` — frozen theorem blueprint, proof records,
  independent/proof audits, correction notes, adoption/integration records,
  and the L1-closure record.
- `MANIFEST_SHA256.txt` — SHA-256 manifest for every packaged file except
  the manifest itself. Verify after extraction with
  `sha256sum -c MANIFEST_SHA256.txt` from the package root.

## Validation summary
- Example 9.4 correction checked at the \(h^\#\) exponent level:
  predecessor \(2187/2187\), successor \(27/2187\) in the GF(8) case
  (`code/validate_audit_fixes.py`).
- The ten EAQECC table rows are verified by `code/validate_code_table.py`
  (`ALL 10 CODE-TABLE ROWS VERIFIED`).
- Corollary 8.5 (variance of the code dimension and zero covariance) uses
  the previously proved N1/N2 results and the exact P1-14 validation record.
- Finite computations are supporting evidence, not substitutes for proofs.

## Remaining blockers / status
- LaTeX compilation and PDF visual proofreading: pending author-side compile.
- Gate G1 remains DEFERRED: no novelty or priority claim is made. The 2023
  related paper has not been compared at theorem level from a lawfully read
  full text.
- Journal-submission artefacts (target journal, cover letter, declarations,
  code/data DOI, ORCID/anonymised copy if required) remain author-side items.
