# Galios-Hull — Final Paper Package (IEEE review version; converted-source commit 6ad0e87)

Review-version source commit: `6ad0e871bc528329920ee50976050c9dfff64068` on branch
`arena/ab8e330d-galios-hull` (converted from the 17-page reading copy at
`3e4f87f`; CI compile commits `22f31ed` and `8fec7dd`). This package
supersedes the packages built for `ea18e8c`, `dfe1995`, `85efaba`,
`7bdc597`, and `3e4f87f`.

## Main files
- `manuscript/P1_15_MANUSCRIPT_DRAFT.tex` — version of record.
  SHA-256: `362710c00998c2aed02ce9e6b561f53955da4666c2cadf9a5a087962d15832f1`
- `manuscript/P1_15_MANUSCRIPT_DRAFT.md` — synchronized Markdown companion.
  SHA-256: `2c69d90c40a9e4afbfed868a21dad5cd87f3c1ce1c7183e39a49e5c69ca2e912`
- `manuscript/P1_15_MANUSCRIPT_DRAFT.pdf` — compiled manuscript (17 pages).
  SHA-256: `db8319853b7332af63a807f28aeafd37f43116976fdfd5fd4bb39f3968787549`
- `manuscript/P1_15_MANUSCRIPT_DRAFT.log` — complete pdflatex log of the
  final pass.
- `manuscript/P1_41_MANUSCRIPT_IEEE_SINGLE_COLUMN.tex` — IEEEtran
  single-column review version (same content; IEEEtran numbering).
- `manuscript/P1_41_MANUSCRIPT_IEEE_SINGLE_COLUMN.pdf` — compiled IEEE
  review PDF (18 pages), with its `.log` alongside.
- `manuscript/references.bib` — standalone BibTeX form of the 25 cited
  references. The `.tex` uses an inline `thebibliography`, so BibTeX is not
  needed to compile the source as supplied.

Author as supplied: Arun Kumar Yadav, School of Basic and Applied Sciences,
K.R. Mangalam University, Gurugram, arunyadav0307@gmail.com.

## Compilation status
Both manuscript versions were compiled with pdflatex (two passes) in a
GitHub Actions (Debian/TeX Live) environment with no errors and no
undefined references or citations: the reading copy has 17 pages; the
IEEEtran single-column review version has 18 pages (within the journal's
50-page single-column submission limit). In the first compiled log of the
reading copy, three unbreakable math lines that overflowed the page were
split (layout only, no content change) and the manuscript recompiled;
remaining overfull boxes stay within the page margins. To recompile
locally, run pdflatex twice on either `.tex` file above (the IEEE version
requires the `IEEEtran` class).

## Contents
- `code/` — validator programs and saved outputs (`validate_p1_14.py`,
  `validate_p1_20.py`, `validate_code_table.py`, `validate_audit_fixes.py`
  and their recorded outputs).
- `supporting_records/` — frozen theorem blueprint, proof records,
  independent/proof audits, correction notes, the N1/N2 integration note,
  the P1-39 references note, and the L1-closure record.
- `MANIFEST_SHA256.txt` — SHA-256 manifest for every packaged file except
  the manifest itself. Verify after extraction with
  `sha256sum -c MANIFEST_SHA256.txt` from the package root.

## Validation summary
- Example 9.4 correction checked at the \(h^\#\) exponent level:
  predecessor \(2187/2187\), successor \(27/2187\) in the GF(8) case
  (`code/validate_audit_fixes.py`).
- The ten EAQECC table rows are verified by `code/validate_code_table.py`.
- Corollary 8.5 (variance of the code dimension and zero covariance) uses
  the previously proved N1/N2 results and the exact P1-14 validation record.
- All 25 bibliography entries are cited; no citation key is unresolved.
- Independent P1-42 edge checks (`code/validate_p1_42_edge_checks.py`,
  48 cases) reproduce the transfer-trace distribution, the moment
  formulas, Cov = 0, the joint symmetry, and the LCD/SO/DC counts.
- Finite computations are supporting evidence, not substitutes for proofs.

## Remaining blockers / status
- Visual proofreading of the compiled PDF by the author is still advised.
- Gate G1 remains DEFERRED: no novelty or priority claim is made. The 2023
  related paper has not been compared at theorem level from a lawfully read
  full text.
- Journal-submission artefacts (target journal, cover letter, declarations,
  code/data DOI, ORCID/anonymised copy if required) remain author-side items.
