# Validation summary

## How to reproduce

From the package root:

```sh
bash tools/run_all_validations.sh
```

The runner executes the five dependency-free Python audits in sequence. Captured console outputs for each program are included beside this summary. Exact arithmetic is implemented in the polynomial-basis models `GF(4)=GF(2)[omega]/(omega^2+omega+1)` and `GF(16)=GF(2)[alpha]/(alpha^4+alpha+1)`.

## Verified claims and concrete test domains

| Audit | Exhaustive test domain | Checks performed |
|---|---|---|
| Paired-modulus duality | 64 code pairs in the split `GF(4)` length-3 example and 64 in the incompatible-twist `GF(16)` example | Dual twist/shift, inverse reciprocal factor maps, relative radicals, restricted pairing rank and nullity identities |
| Coupled transfer matrix | Weights 1 and 2; orbit/cycle lengths 1–6 | Four-state matrix, tensor-swap factorization and parity traces |
| Moments and zero covariance | Every bit/selector assignment for lengths 1–6 | Exact means, variances, directional cross-covariance, zero-count/LCD/LCP identities, including the length-one case |
| EAQECC and distance enumerators | All codewords of each audited code; all nonzero `GF(4)` length-5 codes at `lambda=omega`; all nonzero `GF(16)` length-3 codes at `lambda=alpha^3, alpha^9`; all 49 paired-modulus code pairs | Standard-Hamming distances, dual distances, all LCP distances, EA dimensions/ranks, exact paired normalizer-set distances, MDS/EA-MDS and Singleton checks |
| Global affine pairs | G1: 65,536 ordered pairs for `GF(4) x GF(16)`, `n=5`, twists `(omega,1)`; G2: 4,096 ordered pairs for `n=3`, twists `(1,alpha^3)` and `(1,alpha^9)` | Direct field arithmetic, duals, hulls, coupling ranks, exact histograms and transfer/product identities |

## Distance and Singleton results

- **`GF(4)`, length 5, twist `omega`:** seven nonzero constacyclic codes; all seven are MDS and pass classical and EA Singleton checks. The distances by dimensions `K=5,4,3,3,2,2,1` are `1,2,3,3,4,4,5`. All eight LCP cases were checked; their distances are `1,2,3,3,3,3,2,1`.
- **`GF(16)`, length 3:** for each of twists `alpha^3` and `alpha^9`, seven nonzero codes are checked; all are MDS/EA-MDS. For dimensions `K=3,2,2,2,1,1,1`, distances are `1,2,2,2,3,3,3`.
- **Paired `GF(16)` EA CSS cases:** 49 ordered pairs checked; 24 have positive logical dimension, comprising 12 EA-MDS and 12 Singleton-defect-one cases. All applicable cases pass the EA Singleton bound.
- The corrected G1 factorization is `x^5-omega=(x+omega^2)(x^2+x+omega)(x^2+omega*x+omega)`. The G1 `GF(16)` reciprocal orbit weights are `[2,2]`.

## Convention and scope safeguards

For the paired CSS construction, `C2` is the X-check space and `C1` the Z-check space. With directional pairing rank `c`, the logical dimension is `k_Q=n-K1-K2+c`; the expression `K1+K2-n+c` is rejected as inconsistent (full/full would give `2n`). The paired normalizer differences use the matching left/right dual orientations. The single-field distance audits use the standard Hamming metric. No scalar quantum distance is asserted for the product alphabet `GF(4) x GF(16)` without choosing a coordinate expansion/projection isometry and quantum construction.

These exhaustive computations are independent finite-case checks and do not replace the general mathematical proofs in `manuscript/main.tex`.
