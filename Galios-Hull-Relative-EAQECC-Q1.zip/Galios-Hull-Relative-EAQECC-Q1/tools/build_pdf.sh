#!/usr/bin/env bash
# Build main.pdf; prefer system LaTeX, otherwise use the provisioned Tectonic bundle.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEX="$ROOT/manuscript/main.tex"
PDF="$ROOT/manuscript/main.pdf"
BUILDLOG="$ROOT/traceability/pdf-build.log"
mkdir -p "$ROOT/traceability"

if command -v pdflatex >/dev/null 2>&1 && command -v bibtex >/dev/null 2>&1; then
  cd "$ROOT/manuscript"
  rm -f main.aux main.bbl main.blg main.log main.out main.pdf main.toc
  : > "$BUILDLOG"
  pdflatex -interaction=nonstopmode -halt-on-error -file-line-error main.tex >>"$BUILDLOG" 2>&1
  bibtex main >>"$BUILDLOG" 2>&1
  for pass in 1 2 3; do
    pdflatex -interaction=nonstopmode -halt-on-error -file-line-error main.tex >>"$BUILDLOG" 2>&1
  done
  ENGINELOG="$ROOT/manuscript/main.log"
elif [[ -x "${TECTONIC_BIN:-/tmp/tex-build/tecto/tecto-0.17.0.data/scripts/tectonic}" && -d "${TECTONIC_BUNDLE:-/tmp/tex-build/flat-bundle}" ]]; then
  TECTONIC_BIN="${TECTONIC_BIN:-/tmp/tex-build/tecto/tecto-0.17.0.data/scripts/tectonic}"
  TECTONIC_BUNDLE="${TECTONIC_BUNDLE:-/tmp/tex-build/flat-bundle}"
  "$TECTONIC_BIN" --bundle "$TECTONIC_BUNDLE" --only-cached \
    --keep-logs --keep-intermediates --reruns 3 \
    --outdir "$ROOT/manuscript" "$TEX" >"$BUILDLOG" 2>&1
  ENGINELOG="$ROOT/manuscript/main.log"
else
  echo "ERROR: Need pdflatex+bibtex or the provisioned Tectonic binary and bundle." >&2
  exit 127
fi

if grep -Ei 'warning:|LaTeX Warning|Package .* Warning|Overfull \\hbox|Underfull \\hbox|LaTeX Error|undefined references|undefined citations' "$BUILDLOG" "$ENGINELOG"; then
  echo "ERROR: warnings or unresolved references were detected; see $BUILDLOG and main.log." >&2
  exit 2
fi
test -s "$PDF"
echo "Built warning-free PDF: $PDF"
