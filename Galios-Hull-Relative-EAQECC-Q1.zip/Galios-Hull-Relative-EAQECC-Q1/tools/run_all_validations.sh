#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/validation"
for script in \
  validate_bipartite_incompatible_duality.py \
  validate_coupled_4x4_transfer.py \
  validate_moments_and_zero_covariance.py \
  validate_eaqecc_enumerators.py \
  validate_global_affine_pairs.py; do
  (cd "$ROOT/code" && python3 "$script") | tee "$ROOT/validation/${script%.py}.out"
done
printf 'All pure-Python audits completed.\n' | tee "$ROOT/validation/run_all.out"
