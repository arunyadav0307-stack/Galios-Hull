#!/usr/bin/env python3
"""Verify 4x4 transfer weights and the parity reduction for orbit lengths 1..6."""
from orbit_model import four_state_matrix, matmul, matpow, trace, T


def kron(A,B): return [[A[i//len(B)][j//len(B)]*B[i%len(B)][j%len(B)] for j in range(len(A)*len(B))] for i in range(len(A)*len(B))]
def swap4(A):
    # (B tensor C) P_swap: column index (t1,t2) receives reversed factors.
    P=[[int(j//2==i%2 and j%2==i//2) for j in range(4)] for i in range(4)]
    return [[sum(A[i][k]*P[k][j] for k in range(4)) for j in range(4)] for i in range(4)]

for w in (1,2):
    u1,u2,y12,y21=2,3,5,7
    M=four_state_matrix(w,u1,u2,1,1,y12,y21)
    # Check each entry against its explicit tensor expression by row/column formula.
    for a in range(4):
      for b in range(4):
        r1,r2=((0,0),(0,1),(1,0),(1,1))[a]
        t1,t2=((0,0),(0,1),(1,0),(1,1))[b]
        expected=u1**(w*(1-t1))*u2**(w*(1-t2))*y12**(w*r2*(1-t1))*y21**(w*r1*(1-t2))
        assert M[a][b]==expected
    B=kron(T(w,u2,y21),T(w,u1,y12))
    # Matrix multiplication with swap on the right.
    P=[[int((j//2,j%2)==(i%2,i//2)) for j in range(4)] for i in range(4)]
    BP=[[sum(B[i][k]*P[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
    assert M==BP
    S= [[sum(T(w,u2,y21)[i][k]*T(w,u1,y12)[k][j] for k in range(2)) for j in range(2)] for i in range(2)]
    for a in range(1,7):
        lhs=trace(matpow(M,a))
        rhs=trace(matpow(S,a)) if a%2 else trace(matpow(S,a//2))**2
        assert lhs==rhs,(w,a,lhs,rhs)
print('4x4 destination matrix, tensor-swap factorization, and parity traces verified for w=1,2; a=1..6.')
