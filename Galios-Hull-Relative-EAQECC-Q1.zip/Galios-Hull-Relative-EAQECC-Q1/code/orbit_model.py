"""Exact finite-state model for the factor/orbit enumerators in the manuscript.

All arithmetic here is integer arithmetic; no floating point or third-party
package is used. A factor is represented by one binary membership variable.
"""
from itertools import product
from fractions import Fraction
from math import gcd


def bits(a):
    return product((0, 1), repeat=a)


def orbit_stats(a):
    """Return exact count and moment sums for a single orbit, unit weight."""
    rows = []
    for x in bits(a):
        for y in bits(a):
            h12 = sum(y[i] * (1-x[(i+1) % a]) for i in range(a))
            h21 = sum(x[i] * (1-y[(i+1) % a]) for i in range(a))
            h1 = sum(x[i] * (1-x[(i+1) % a]) for i in range(a))
            h2 = sum(y[i] * (1-y[(i+1) % a]) for i in range(a))
            k1, k2 = sum(x), sum(y)
            c1, c2 = k1-h1, k2-h2
            rows.append((h12,h21,h1,h2,k1,k2,c1,c2))
    n=len(rows)
    means=[Fraction(sum(r[j] for r in rows),n) for j in range(8)]
    cov=lambda j,l: Fraction(sum(r[j]*r[l] for r in rows),n)-means[j]*means[l]
    return rows, means, cov


def cycle_edges(a):
    """Directed edge indices i -> i+1 (mod a)."""
    return tuple((i,(i+1)%a) for i in range(a))


def four_state_matrix(w, u1=1, u2=1, z1=1, z2=1, y12=1, y21=1):
    """Numeric/symbolic-friendly destination-weight matrix, states (r1,r2)."""
    states=((0,0),(0,1),(1,0),(1,1))
    M=[]
    for r1,r2 in states:
        row=[]
        for t1,t2 in states:
            row.append(u1**(w*(1-t1))*u2**(w*(1-t2))*
                       z1**(w*r1*(1-t1))*z2**(w*r2*(1-t2))*
                       y12**(w*r2*(1-t1))*y21**(w*r1*(1-t2)))
        M.append(row)
    return M


def matmul(A,B):
    return [[sum(A[i][k]*B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]


def matpow(A,n):
    R=[[int(i==j) for j in range(len(A))] for i in range(len(A))]
    while n:
        if n&1: R=matmul(R,A)
        A=matmul(A,A); n//=2
    return R


def trace(A): return sum(A[i][i] for i in range(len(A)))


def T(w,u,y): return [[u**w,1],[u**w*y**w,1]]


def bipartite_factor_table(w=1):
    """The four mutually exclusive local states and their monomials."""
    return ((1,1,1,1,1),)  # documented here; polynomial built in caller


def pair_enumerator_for_permutation(perm):
    """Exhaust all selector pairs; perm maps C1 factors to C2 factors."""
    n=len(perm); out=[]
    for a in range(1<<n):
        for b in range(1<<n):
            # selector 1 means code-dimension constituent; complementary bit
            # convention makes the rank support the simultaneous-zero event.
            k1=k2=hr=hl=cr=0
            for i,j in enumerate(perm):
                e1=(a>>i)&1; e2=(b>>j)&1
                d1,d2=1-e1,1-e2
                c=d1*d2
                k1+=d1; k2+=d2; cr+=c
                hr+=d1-c; hl+=d2-c
            out.append((k1,k2,hr,hl,cr))
    return out


def count_zero_patterns(a, require_self=False):
    """Count pairs with both relative hulls zero; optionally both self hulls."""
    count=0
    for x in bits(a):
        for y in bits(a):
            h12=sum(y[i]*(1-x[(i+1)%a]) for i in range(a))
            h21=sum(x[i]*(1-y[(i+1)%a]) for i in range(a))
            h1=sum(x[i]*(1-x[(i+1)%a]) for i in range(a))
            h2=sum(y[i]*(1-y[(i+1)%a]) for i in range(a))
            if h12==h21==0 and (not require_self or h1==h2==0): count+=1
    return count
