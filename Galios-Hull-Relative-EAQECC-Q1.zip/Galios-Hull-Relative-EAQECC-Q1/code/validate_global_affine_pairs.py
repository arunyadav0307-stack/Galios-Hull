#!/usr/bin/env python3
"""Field-specific exhaustive mixed-product audits in F4 x F16.

G1: n=5, twists (omega,1), 256 codes and all 65,536 ordered pairs.
G2: n=3, twists (1,alpha^3) and (1,alpha^9), all 4,096 paired-modulus pairs.
All code spaces, duals, intersections and restricted Gram ranks are computed
from explicit polynomial generators and exact GF(2^m) arithmetic.
"""
from collections import Counter
from itertools import product
from finite_field_audit import (BinaryField, code_from_generator, rref,
    right_dual, left_dual, is_shift_invariant, intersection_dimension)


def pmul(F,a,b):
    out=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): out[i+j]=F.add(out[i+j],F.mul(x,y))
    while len(out)>1 and out[-1]==0: out.pop()
    return tuple(out)

def factor_product(F,factors):
    out=(1,)
    for f in factors: out=pmul(F,out,f)
    return out

def sharp(F,h,k):
    """Normalized theta-reciprocal; coefficient arrays are ascending."""
    d=len(h)-1; den=F.frob(h[0],k)
    return tuple(F.div(F.frob(h[d-j],k),den) for j in range(d+1))

def cycle_partition(factors, tau):
    unseen=set(factors); cycles=[]
    while unseen:
        start=min(unseen); cyc=[]; x=start
        while x not in cyc:
            cyc.append(x);unseen.discard(x);x=tau[x]
        assert x==start
        cycles.append(tuple(cyc))
    return cycles

def code_list(F,factors,n,lam):
    out=[]
    for mask in range(1<<len(factors)):
        selected=[f for i,f in enumerate(factors) if mask>>i&1]
        gen=factor_product(F,selected)
        C=code_from_generator(F,gen,n,lam)
        assert is_shift_invariant(F,C,lam,n)
        out.append((mask,C))
    return out

def gram_rank(F,B,A,k):
    rows=[]
    for b in B:
        row=[]
        for a in A:
            z=0
            for bi,ai in zip(b,a): z=F.add(z,F.mul(bi,F.frob(ai,k)))
            row.append(z)
        rows.append(tuple(row))
    return len(rref(F,rows,len(A))[0])

def component_pairs(F,n,k,m,lam1,fac1,lam2,fac2,mode):
    A=code_list(F,fac1,n,lam1); B=code_list(F,fac2,n,lam2)
    da=[right_dual(F,C,k,n) for _,C in A]
    db=[right_dual(F,C,k,n) for _,C in B]
    la=[left_dual(F,C,k,n) for _,C in A]
    lb=[left_dual(F,C,k,n) for _,C in B]
    if mode=='compatible':
        assert all(is_shift_invariant(F,D,lam2,n) for D in da)
        assert all(is_shift_invariant(F,D,lam1,n) for D in db)
        assert all(is_shift_invariant(F,D,lam2,n) for D in la)
        assert all(is_shift_invariant(F,D,lam1,n) for D in lb)
    else:
        assert all(is_shift_invariant(F,D,lam1,n) for D in db)
        assert all(is_shift_invariant(F,D,lam2,n) for D in la)
    hist=Counter(); records=[]
    for i,(_,C1) in enumerate(A):
      for j,(_,C2) in enumerate(B):
        k1=m*len(C1);k2=m*len(C2)
        hr=m*intersection_dimension(F,C1,db[j],n)
        hl_left=m*intersection_dimension(F,C2,la[i],n)
        cr=m*gram_rank(F,C2,C1,k)
        assert k1==hr+cr and k2==hl_left+cr,(n,i,j,k1,k2,hr,hl_left,cr)
        if mode=='compatible':
            h1=m*intersection_dimension(F,C1,da[i],n)
            h2=m*intersection_dimension(F,C2,db[j],n)
            h21=m*intersection_dimension(F,C2,da[i],n)  # reverse right dual, as in the 4x4 theorem
            cr21=m*gram_rank(F,C1,C2,k)
            hl21=m*intersection_dimension(F,C1,lb[j],n)
            assert k2==h21+cr21 and k1==hl21+cr21
            # Same-code left/right hull dimensions agree.
            assert h1==m*intersection_dimension(F,C1,la[i],n)
            assert h2==m*intersection_dimension(F,C2,lb[j],n)
            key=(k1,k2,h1,h2,hr,h21)
        else: key=(k1,k2,hr,hl_left,cr)
        hist[key]+=1;records.append(key)
    return A,B,hist,records

# Sparse multivariate polynomials are dictionaries exponent_tuple -> integer.
def padd(A,B):
    R=Counter(A);R.update(B);return +R
def pmul_poly(A,B):
    R=Counter()
    for a,ca in A.items():
      for b,cb in B.items():R[tuple(x+y for x,y in zip(a,b))]+=ca*cb
    return +R
def mono(ex):return {tuple(ex):1}
def matmul(A,B):
    rows=len(A); cols=len(B[0]); mid=len(B)
    return [[sum_poly([pmul_poly(A[i][k],B[k][j]) for k in range(mid)]) for j in range(cols)] for i in range(rows)]
def sum_poly(ps):
    r=Counter()
    for p in ps:r.update(p)
    return +r
def matpow(A,n,zero):
    N=len(A);# Identity entries require a dimension-independent zero exponent tuple.
    dim=len(next(iter(A[0][0])))
    R=[[({(0,)*dim:1} if i==j else {}) for j in range(N)] for i in range(N)]
    while n:
        if n&1:R=matmul(R,A)
        n//=2
        if n:A=matmul(A,A)
    return R
def tr(A):return sum_poly([A[i][i] for i in range(len(A))])
def poly_product_orbits(polys,dim):
    out={(0,)*dim:1}
    for p in polys:out=pmul_poly(out,p)
    return out

def transfer6(w):
    states=((0,0),(0,1),(1,0),(1,1)); M=[]
    for r1,r2 in states:
      row=[]
      for t1,t2 in states:
        row.append(mono((w*(1-t1),w*(1-t2),w*r1*(1-t1),w*r2*(1-t2),w*r2*(1-t1),w*r1*(1-t2))))
      M.append(row)
    return M

def Trel(w,which):
    # Variable order (K1,K2,H12,H21); which=1 means code 1, otherwise code 2.
    M=[]
    for r in (0,1):
      row=[]
      for t in (0,1):
        b=w*(1-t)
        row.append(mono((b,0,w*r*(1-t),0) if which==1 else (0,b,0,w*r*(1-t))))
      M.append(row)
    return M

def orbit_transfer_polys(cycles,weights):
    full=[];relative=[]
    for cyc,w in zip(cycles,weights):
        a=len(cyc)
        full.append(tr(matpow(transfer6(w),a,0)))
        B=Trel(w,2);C=Trel(w,1);S=matmul(B,C)
        if a%2: rp=tr(matpow(S,a,0))
        else:
            rp=pmul_poly(tr(matpow(S,a//2,0)),tr(matpow(S,a//2,0)))
        direct_rel=tr(matpow([[mono((w*(1-t1),w*(1-t2),w*r2*(1-t1),w*r1*(1-t2))) for t1,t2 in ((0,0),(0,1),(1,0),(1,1))] for r1,r2 in ((0,0),(0,1),(1,0),(1,1))],a,0))
        # 4-state relative trace is the z1=z2=1 specialization.
        marginal=Counter()
        for ex,c in full[-1].items(): marginal[(ex[0],ex[1],ex[4],ex[5])]+=c
        assert +marginal==+rp==+direct_rel,(a,w)
        relative.append(rp)
    return poly_product_orbits(full,6),poly_product_orbits(relative,4)

def actual_global_compatible():
    F4=BinaryField(2,0b111); w4=2;lam4=w4
    # Correct factorization: (x+omega^2)(x^2+x+omega)(x^2+omega*x+omega).
    f4=((3,1),(2,1,1),(2,2,1))
    assert factor_product(F4,f4)==(w4,0,0,0,0,1)
    assert len(f4)==3 and all(len(f)==2 or all(F4.add(F4.add(F4.mul(x,x),F4.mul(f[1],x)),f[0]) for x in range(4)) for f in f4 if len(f)==3)
    tau4={f:sharp(F4,f,1) for f in f4};assert set(tau4.values())==set(f4)
    cyc4=cycle_partition(f4,tau4);assert sorted(map(len,cyc4))==[1,2]

    F16=BinaryField(4,0b10011);alpha=2;lam16=1;m16=2
    roots16=tuple(F16.pow(alpha,e) for e in (0,3,6,9,12))
    f16=tuple((r,1) for r in roots16)
    assert factor_product(F16,f16)==(1,0,0,0,0,1)
    tau16={f:sharp(F16,f,3) for f in f16};assert set(tau16.values())==set(f16)
    cyc16=cycle_partition(f16,tau16);assert sorted(map(len,cyc16))==[1,4]

    _,_,h4,records4=component_pairs(F4,5,1,1,lam4,f4,lam4,f4,'compatible')
    _,_,h16,records16=component_pairs(F16,5,1,2,lam16,f16,lam16,f16,'compatible')
    actual=Counter()
    # Each record is tied to a concrete generator mask on that component;
    # their Cartesian product enumerates the 256^2 global labeled pairs.
    for s4 in records4:
      for s16 in records16:actual[tuple(a+b for a,b in zip(s4,s16))]+=1
    assert sum(actual.values())==65536
    w4=[len(cyc[0])-1 for cyc in cyc4]
    w16=[2*(len(cyc[0])-1) for cyc in cyc16]
    t4,r4=orbit_transfer_polys(cyc4,w4)
    t16,r16=orbit_transfer_polys(cyc16,w16)
    predicted=pmul_poly(t4,t16)
    predrel=pmul_poly(r4,r16)
    assert +actual==+predicted, f"full six-variable mismatch: {len(actual)} != {len(predicted)}"
    marginal=Counter()
    for ex,c in actual.items():marginal[(ex[0],ex[1],ex[4],ex[5])]+=c
    assert +marginal==+predrel
    print('G1 concrete F4 x F16, n=5, k=1, twists (omega,1):')
    print('  factors: 3 over F4 plus 5 over F16; reciprocal orbit lengths [1,2] and [1,4]')
    print('  8 x 32 = 256 concrete ideals; all 65,536 ordered code pairs directly checked')
    print(f'  six-variable histogram: {len(actual)} nonzero cells; direct field computation = 4x4 transfer product')
    print('  relative-only marginal = tensor-swap parity-split 2x2 product; exact discrepancy 0')


def actual_global_paired():
    F4=BinaryField(2,0b111); f4=tuple((r,1) for r in (1,2,3))
    assert factor_product(F4,f4)==(1,0,0,1)
    F16=BinaryField(4,0b10011);alpha=2
    roots1=tuple(F16.pow(alpha,e) for e in (1,6,11))
    roots2=tuple(F16.pow(alpha,e) for e in (3,8,13))
    f16a=tuple((r,1) for r in roots1);f16b=tuple((r,1) for r in roots2)
    la=F16.pow(alpha,3);lb=F16.pow(alpha,9)
    assert factor_product(F16,f16a)==(la,0,0,1)
    assert factor_product(F16,f16b)==(lb,0,0,1)
    # G2 product component distributions and direct polynomial enumerator.
    _,_,h4,records4=component_pairs(F4,3,1,1,1,f4,1,f4,'paired')
    _,_,h16,records16=component_pairs(F16,3,1,2,la,f16a,lb,f16b,'paired')
    actual=Counter()
    for a in records4:
      for b in records16:actual[tuple(x+y for x,y in zip(a,b))]+=1
    assert sum(actual.values())==4096
    # Exact bipartite factor polynomial. Right map is rho-reciprocal from lambda*;
    # left map is sigma-reciprocal from lambda. Pair factors in corresponding order.
    rho4={f:sharp(F4,f,1) for f in f4}; sig4={f:sharp(F4,f,1) for f in f4}
    rho16={f:sharp(F16,f,3) for f in f16b}; sig16={f:sharp(F16,f,1) for f in f16a}
    assert set(rho4.values())==set(f4)==set(sig4.values())
    assert set(rho16.values())==set(f16a) and set(sig16.values())==set(f16b)
    # local edge monomials for variables (K1,K2,HR,HL,c), weights 1/2.
    expected={(0,0,0,0,0):1}
    for w in (1,1,1,2,2,2):
        local={(0,0,0,0,0):1,(w,0,w,0,0):1,(0,w,0,w,0):1,(w,w,0,0,w):1}
        expected=pmul_poly(expected,local)
    for key,count in actual.items():
        expected.setdefault(key,0)
    assert +actual==+expected, (len(actual),len(expected))
    print('G2 concrete F4 x F16, n=3, k=1, twists (1,alpha^3)/(1,alpha^9):')
    print('  3+3 factors; 64 codes on each side; all 4,096 paired-modulus pairs directly checked')
    print(f'  five-variable bipartite histogram: {len(actual)} nonzero cells; factor product discrepancy 0')

if __name__=='__main__':
    actual_global_compatible()
    actual_global_paired()
