"""Tiny exact GF(2^m) and linear algebra toolkit for the concrete audits."""
class BinaryField:
    def __init__(self, degree, modulus): self.m,self.mod=degree,modulus; self.q=1<<degree
    def add(self,a,b): return a^b
    def mul(self,a,b):
        r=0; x=a
        while b:
            if b&1:r^=x
            b>>=1; x<<=1
            if x&(1<<self.m):x^=self.mod
        return r
    def pow(self,a,n):
        r=1
        while n:
            if n&1:r=self.mul(r,a)
            a=self.mul(a,a);n>>=1
        return r
    def inv(self,a):
        if not a: raise ZeroDivisionError
        return self.pow(a,self.q-2)
    def div(self,a,b): return self.mul(a,self.inv(b))
    def frob(self,a,k): return self.pow(a,1<<k)
    def scale(self,a,s): return self.mul(a,s)


def rref(F, rows, n):
    A=[list(r) for r in rows]; piv=[]; rr=0
    for c in range(n):
        z=next((i for i in range(rr,len(A)) if A[i][c]),None)
        if z is None: continue
        A[rr],A[z]=A[z],A[rr]; iv=F.inv(A[rr][c]); A[rr]=[F.mul(iv,x) for x in A[rr]]
        for i in range(len(A)):
            if i!=rr and A[i][c]:
                q=A[i][c]; A[i]=[F.add(A[i][j],F.mul(q,A[rr][j])) for j in range(n)]
        piv.append(c);rr+=1
        if rr==len(A):break
    return tuple(tuple(r) for r in A[:rr]),tuple(piv)


def nullspace(F, rows, n):
    R,piv=rref(F,rows,n); free=[j for j in range(n) if j not in piv]; out=[]
    for f in free:
        v=[0]*n;v[f]=1
        for i,p in enumerate(piv):v[p]=R[i][f]
        out.append(tuple(v))
    return rref(F,out,n)[0]


def shift(F,v,lam): return (F.mul(lam,v[-1]),)+tuple(v[:-1])

def code_from_generator(F,g,n,lam):
    # A monic degree-n divisor is the modulus itself and generates zero.
    if len(g)>n: return ()
    # g coefficients in ascending order; shifts of g generate the ideal.
    v=tuple(g)+(0,)*(n-len(g)); rows=[]
    for _ in range(n):
        rows.append(v);v=shift(F,v,lam)
    return rref(F,rows,n)[0]

def poly_product(F, factors):
    a=[1]
    for root in factors: # factor x-root
        b=[0]*(len(a)+1)
        for i,c in enumerate(a): b[i]=F.add(b[i],F.mul(c,root));b[i+1]=F.add(b[i+1],c)
        a=b
    return tuple(a)

def span_basis(F,A,B,n): return rref(F,list(A)+list(B),n)[0]
def intersection_dimension(F,A,B,n): return len(A)+len(B)-len(span_basis(F,A,B,n))

def right_dual(F,C,k,n):
    # <c,y>=0 iff the row c dotted with z=sigma(y) is zero.
    Z=nullspace(F,C,n);rho=(-k) % F.m
    Y=[tuple(F.frob(z,rho) for z in row) for row in Z]
    return rref(F,Y,n)[0]

def left_dual(F,C,k,n):
    # <x,c>=sum x_i sigma(c_i); solve directly for x.
    A=[tuple(F.frob(c,k) for c in row) for row in C]
    return nullspace(F,A,n)

def is_shift_invariant(F,C,lam,n):
    R,piv=rref(F,C,n)
    # Reduce each shifted basis row against the RREF basis.
    for v in R:
        w=shift(F,v,lam)
        for row,p in zip(R,piv):
            if w[p]:
                q=w[p];w=tuple(F.add(w[j],F.mul(q,row[j])) for j in range(n))
        if any(w):return False
    return True
