# Validation code guide

Run all five independent audits from the package root with `bash tools/run_all_validations.sh`. The runner changes into `code/` before invoking each Python program, so the local support-module imports resolve. Python 3 is required; the validators use only the standard library.

## Runnable validation programs

- `validate_bipartite_incompatible_duality.py` — exact field-level checks of paired-modulus dual closure, twist shifts, reciprocal factor maps, radicals, and restricted-pairing/coupling-rank identities in split `GF(4)` and incompatible-twist `GF(16)` examples.
- `validate_coupled_4x4_transfer.py` — constructs and checks the four-state transfer matrix, its tensor-swap factorization, and parity-trace identities for weights 1 and 2 and cycle lengths 1 through 6.
- `validate_moments_and_zero_covariance.py` — exhaustively checks exact orbit means, variances and covariances, zero-count identities, LCD/LCP counts, and the length-one boundary case.
- `validate_eaqecc_enumerators.py` — checks single-code EA rank data and concrete binary sanity examples; exhaustively enumerates standard Hamming distances, MDS/near-MDS and Singleton outcomes for all nonzero `GF(4)` length-5 codes and `GF(16)` length-3 codes under both twists; evaluates every LCP and all 49 paired-modulus code pairs, including exact normalizer-set distances and EA Singleton conditions.
- `validate_global_affine_pairs.py` — directly constructs the `GF(4) x GF(16)` examples and checks all 65,536 G1 and 4,096 G2 ordered code pairs, histograms, directional duals, hulls, restricted Gram ranks, and transfer-product identities.

## Supporting modules (required)

- `finite_field_audit.py` — finite-field arithmetic, polynomial/constacyclic ideal generation, linear-code operations, duals, hulls and restricted-pairing ranks used by three audits.
- `orbit_model.py` — exact combinatorial/orbit and transfer-matrix utilities used by three audits.

The saved per-program console outputs are in `../validation/*.out`. The audits corroborate these concrete finite cases; they do not replace the general proofs in the manuscript.
