#!/usr/bin/env python3
"""Exact EA rank moments and exhaustive finite-field distance audits.

This script first checks the small-orbit EA moment identities and the binary
CSS sanity examples. It then exhausts every constacyclic ideal in the GF(4)
length-five compatible example and every nonzero code/pair in the GF(16)
length-three incompatible-twist example. Codeword weights are computed by
explicit enumeration in the standard Hamming metric (no Gray map).
"""
from fractions import Fraction
from itertools import product
from orbit_model import bits
from finite_field_audit import (
    BinaryField, code_from_generator, right_dual, left_dual,
    intersection_dimension, rref,
)

# Exact one-code EA rank distribution on short reciprocal orbits.
for a in range(1, 7):
    vals = []
    for x in bits(a):
        h = sum(x[i] * (1 - x[(i + 1) % a]) for i in range(a))
        vals.append(sum(x) - h)
    mean = Fraction(sum(vals), len(vals))
    var = Fraction(sum((v - mean) ** 2 for v in vals), len(vals))
    target_mean = Fraction(1, 2) if a == 1 else Fraction(a, 4)
    target_var = (Fraction(1, 4) if a == 1 else
                  Fraction(3, 4) if a == 2 else Fraction(5 * a, 16))
    assert (mean, var) == (target_mean, target_var), (a, mean, var)
    print(f'EA orbit a={a}: E[c]={mean}, Var(c)={var}')

# Small binary EA-CSS and LCP construction examples, independently enumerated.
zero = (0, 0, 0)
rep = {zero, (1, 1, 1)}
par = {v for v in product((0, 1), repeat=3) if sum(v) % 2 == 0}
def wt(v): return sum(v)
def d(C): return min((wt(x) for x in C if x != zero), default=None)
def dot(x, y): return sum(a * b for a, b in zip(x, y)) % 2
def dual(C):
    return {x for x in product((0, 1), repeat=3)
            if all(dot(x, c) == 0 for c in C)}
assert dual(rep) == par and dual(par) == rep
for C, kclass, expected in ((rep, 1, (0, 2, 1)), (par, 2, (3, 2, 2))):
    Cperp = dual(C)
    c = 1 if C == rep else 2
    kq = 2 * kclass - 3 + c
    dq = min(min(wt(x) for x in Cperp - C if x != zero),
             min(wt(x) for x in C - Cperp if x != zero))
    assert (kq, dq, c) == expected
    print(f'binary EA-CSS sanity check: [[3,{kq},{dq};{c}]]')
assert rep & par == {zero} and len(rep) * len(par) == 8
print('binary LCP sanity check: repetition ⊕ even-parity-perp = F_2^3; d_LCP=3')


def pprod(F, a, b):
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] = F.add(out[i + j], F.mul(x, y))
    return tuple(out)


def pprod_many(F, polys):
    out = (1,)
    for f in polys:
        out = pprod(F, out, f)
    return out


def subsets(seq):
    for mask in range(1 << len(seq)):
        yield mask, tuple(x for i, x in enumerate(seq) if (mask >> i) & 1)


def span(F, basis, n):
    q = F.q
    words = set()
    for coeffs in product(range(q), repeat=len(basis)):
        word = [0] * n
        for a, row in zip(coeffs, basis):
            for i, x in enumerate(row):
                word[i] = F.add(word[i], F.mul(a, x))
        words.add(tuple(word))
    return frozenset(words)


def hamming_distance(C):
    return min((sum(x != 0 for x in word) for word in C if any(word)), default=None)


def subspace_dimension(F, C):
    size=len(C)
    h=0
    while F.q**h < size: h+=1
    assert F.q**h==size
    return h


def cross_rank(F, C1, C2, k):
    """Rank of <C2,C1>_k, rows indexed by a basis of C2."""
    G = []
    for b in C2:
        G.append(tuple(sum_field(F, (F.mul(bi, F.frob(ai, k))
                                 for bi, ai in zip(b, a))) for a in C1))
    return len(rref(F, G, len(C1))[0]) if C1 else 0


def sum_field(F, values):
    out = 0
    for x in values:
        out = F.add(out, x)
    return out


def diff_distance(A, B):
    """Minimum nonzero Hamming weight in A\B, or None if empty."""
    return min((sum(x != 0 for x in v) for v in A - B if any(v)), default=None)


def singleton_slack(n, K, dist):
    return n - K + 1 - dist


def format_distance(d):
    return 'infinity (zero code)' if d is None else str(d)


def field_element_name(F, a, alpha=2):
    if a == 0: return '0'
    if a == 1: return '1'
    for e in range(1, F.q - 1):
        if F.pow(alpha, e) == a:
            return f'alpha^{e}'
    return f'[{a}]'


def poly_name(F, g, alpha=2, omega=False):
    terms = []
    for i, c in reversed(list(enumerate(g))):
        if c == 0: continue
        if omega:
            coeff = {1: '1', 2: 'omega', 3: 'omega^2'}[c]
        else:
            coeff = field_element_name(F, c, alpha)
        if i == 0: term = coeff
        elif i == 1: term = 'x' if coeff == '1' else f'{coeff}*x'
        else: term = f'x^{i}' if coeff == '1' else f'{coeff}*x^{i}'
        terms.append(term)
    return ' + '.join(terms) if terms else '0'


def enumerate_constacyclic(F, factors, n, lam, k, alpha=2, omega=False):
    """Return every ideal, its generator, basis, words, duals, and distance."""
    out = []
    for mask, selected in subsets(factors):
        g = pprod_many(F, selected)
        basis = code_from_generator(F, g, n, lam)
        assert len(basis) == n - (len(g) - 1)
        C = span(F, basis, n)
        Rbasis = right_dual(F, basis, k, n)
        Lbasis = left_dual(F, basis, k, n)
        R = frozenset(span(F, Rbasis, n))
        L = frozenset(span(F, Lbasis, n))
        assert len(R) == F.q ** (n - len(basis))
        out.append({
            'mask': mask, 'selected': selected, 'g': g,
            'gname': poly_name(F, g, alpha, omega), 'basis': basis,
            'C': C, 'R': R, 'L': L, 'Rbasis': Rbasis, 'Lbasis': Lbasis,
            'K': len(basis),
            'd': hamming_distance(C), 'dR': hamming_distance(R),
            'dL': hamming_distance(L),
        })
    return out


def verify_classical_singleton(rows, n, label):
    mds = near = 0
    for row in rows:
        if row['K'] == 0: continue
        s = singleton_slack(n, row['K'], row['d'])
        assert s >= 0, (label, row['gname'], row['K'], row['d'], s)
        mds += s == 0
        near += s == 1
    print(f'{label}: {sum(r["K"] > 0 for r in rows)} nonzero codes; '
          f'{mds} MDS and {near} near-MDS (Singleton defect 1); all satisfy Singleton')


def verify_single_ea(F, rows, n, k, label):
    exact = near = dual_exact = dual_near = 0
    for row in rows:
        assert row['dR'] == row['dL'], (label, row['gname'], row['dR'], row['dL'])
        K, h = row['K'], subspace_dimension(F, row['C'] & row['R'])
        check_rank = cross_rank(F, row['Rbasis'], row['Rbasis'], k)
        assert check_rank == n - K - h, (label, row['gname'], check_rank, n-K-h)
        dual_check_rank = cross_rank(F, row['basis'], row['basis'], k)
        assert dual_check_rank == K - h, (label, row['gname'], dual_check_rank, K-h)
        if K:
            kq, c = K - h, n - K - h
            assert c >= 0 and kq >= 0
            slack = n + c - kq - 2 * (row['d'] - 1)
            assert slack >= 0, (label, row['gname'], K, h, row['d'], c, slack)
            exact += slack == 0
            near += slack == 1
        if row['dR'] is not None:
            kq_dual, c_dual = n - K - h, K - h
            slack_dual = n + c_dual - kq_dual - 2 * (row['dR'] - 1)
            assert slack_dual >= 0, (label, row['gname'], K, h, row['dR'], slack_dual)
            dual_exact += slack_dual == 0
            dual_near += slack_dual == 1
    print(f'{label}: EA Singleton passed; {exact} EA-MDS / {near} defect-1 from C; '
          f'{dual_exact} EA-MDS / {dual_near} defect-1 from C^perp')


def enumerate_lcps(F, rows1, rows2, n):
    out = []
    for a in rows1:
        for b in rows2:
            if a['K'] + subspace_dimension(F, b['R']) != n:
                continue
            if len(a['C'] & b['R']) != 1:
                continue
            d1 = a['d']
            d2 = b['dR']
            dlcp = min(x for x in (d1, d2) if x is not None)
            assert d1 is None or d1 <= n-a['K']+1
            assert d2 is None or d2 <= n-subspace_dimension(F,b['R'])+1
            out.append((a, b, dlcp))
    return out


def print_code_table(F, rows, n, label):
    print(f'{label} code table: generator; K; d_H(C); d_H(C^perp_R); '
          'EA [n,K-H,d;n-K-H]')
    for r in rows:
        if not r['K']: continue
        h = subspace_dimension(F, r['C'] & r['R'])
        print(f'  {r["gname"]}; {r["K"]}; {r["d"]}; '
              f'{format_distance(r["dR"])}; '
              f'[[{n},{r["K"]-h},{r["d"]};{n-r["K"]-h}]]')


# GF(4), n=5, lambda=omega, k=1. Values are 0,1,omega,omega^2.
F4 = BinaryField(2, 0b111)
omega, omega2 = 2, 3
f4 = ((omega2, 1), (omega, 1, 1), (omega, omega, 1))
assert pprod_many(F4, f4) == (omega, 0, 0, 0, 0, 1)
rows4 = enumerate_constacyclic(F4, f4, 5, omega, 1, omega= True)
verify_classical_singleton(rows4, 5, 'GF(4), n=5, lambda=omega')
verify_single_ea(F4, rows4, 5, 1, 'GF(4), n=5')
print_code_table(F4, rows4, 5, 'GF(4)')
lcps4 = enumerate_lcps(F4, rows4, rows4, 5)
assert len(lcps4) == 8
print('GF(4) LCP table: g1; g2; d_H(C1); d_H(C2^perp_R); d_LCP')
for a, b, dl in lcps4:
    print(f'  {a["gname"]}; {b["gname"]}; {format_distance(a["d"])}; '
          f'{format_distance(b["dR"])}; {dl}')

# GF(16), n=3, lambda=alpha^3, lambda*=alpha^9, k=1.
F16 = BinaryField(4, 0b10011)
alpha = 2
lam1, lam2 = F16.pow(alpha, 3), F16.pow(alpha, 9)
roots1 = tuple(F16.pow(alpha, e) for e in (1, 6, 11))
roots2 = tuple(F16.pow(alpha, e) for e in (3, 8, 13))
f16a = tuple((r, 1) for r in roots1)
f16b = tuple((r, 1) for r in roots2)
assert pprod_many(F16, f16a) == (lam1, 0, 0, 1)
assert pprod_many(F16, f16b) == (lam2, 0, 0, 1)
rows16a = enumerate_constacyclic(F16, f16a, 3, lam1, 1)
rows16b = enumerate_constacyclic(F16, f16b, 3, lam2, 1)
verify_classical_singleton(rows16a, 3, 'GF(16), lambda=alpha^3')
verify_classical_singleton(rows16b, 3, 'GF(16), lambda*=alpha^9')
verify_single_ea(F16, rows16a, 3, 1, 'GF(16), lambda=alpha^3')
verify_single_ea(F16, rows16b, 3, 1, 'GF(16), lambda*=alpha^9')
print_code_table(F16, rows16a, 3, 'GF(16), lambda=alpha^3')
print_code_table(F16, rows16b, 3, 'GF(16), lambda*=alpha^9')

# Exhaust every nonzero paired-modulus code pair and compute exact paired CSS data.
# For X checks C2 and Z checks C1, k_Q=n-K1-K2+c, where c is rank <C2,C1>.
# The distance candidates are C1^perp_L\C2 and C2^perp_R\C1; differences
# remove stabilizer operators.
pair_rows = []
for a in rows16a:
    if not a['K']: continue
    for b in rows16b:
        if not b['K']: continue
        c = cross_rank(F16, a['basis'], b['basis'], 1)
        kq = 3 - a['K'] - b['K'] + c
        dX = diff_distance(a['L'], b['C'])
        dZ = diff_distance(b['R'], a['C'])
        candidates = [d for d in (dX, dZ) if d is not None]
        dq = min(candidates) if candidates else None
        assert c == a['K'] - (subspace_dimension(F16, a['C'] & b['R']))
        assert c == b['K'] - (subspace_dimension(F16, b['C'] & a['L']))
        assert kq >= 0
        if kq > 0:
            assert dq is not None
            slack = 3 + c - kq - 2 * (dq - 1)
            assert slack >= 0, (a['gname'], b['gname'], kq, c, dq, slack)
        else:
            slack = None
        pair_rows.append((a, b, c, kq, dX, dZ, dq, slack))
assert len(pair_rows) == 49
print('GF(16) incompatible paired-modulus table (49 nonzero pairs):')
print('  g1; g2; K1,K2; c; k_Q=3-K1-K2+c; d_X; d_Z; d_Q; EA-Singleton slack')
for a, b, c, kq, dx, dz, dq, slack in pair_rows:
    print(f'  {a["gname"]}; {b["gname"]}; {a["K"]},{b["K"]}; {c}; {kq}; '
          f'{format_distance(dx)}; {format_distance(dz)}; '
          f'{format_distance(dq)}; {"n/a (k_Q=0)" if slack is None else slack}')
mds = sum(s == 0 for *_, s in pair_rows if s is not None)
near = sum(s == 1 for *_, s in pair_rows if s is not None)
print(f'GF(16) paired EA: {sum(s is not None for *_, s in pair_rows)} positive-logical cases; '
      f'{mds} EA-MDS and {near} Singleton-defect-one; all satisfy EA Singleton')

# The proposed k_Q=K1+K2-n+c formula is contradicted by the full/full pair:
# K1=K2=c=n=3 would give k_Q=6 on three physical coordinates.
full1 = next(r for r in rows16a if r['K'] == 3)
full2 = next(r for r in rows16b if r['K'] == 3)
fullrank = cross_rank(F16, full1['basis'], full2['basis'], 1)
assert fullrank == 3
assert full1['K'] + full2['K'] - 3 + fullrank == 6 > 3
print('Referee check: supplied two-code logical-dimension sign is impossible for full/full: '
      'K1=K2=c=n=3 gives 6>n; corrected CSS rank formula uses n-K1-K2+c.')
