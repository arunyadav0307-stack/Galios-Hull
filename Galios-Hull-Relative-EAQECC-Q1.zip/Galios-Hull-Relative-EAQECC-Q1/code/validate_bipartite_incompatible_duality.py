#!/usr/bin/env python3
"""Direct small-field audit of paired-modulus right/left duality.

Cases are the split F4, n=3 cyclic example and the N2-B F16, n=3 example
(q=4, K=F16, k=1, lambda=alpha^3). Each has 8 principal ideals on each
side, hence all 64 ordered pairs are checked by direct vector arithmetic.
"""
from itertools import combinations
from finite_field_audit import (BinaryField, code_from_generator, poly_product,
    right_dual, left_dual, is_shift_invariant, intersection_dimension, rref)


def subsets(xs):
    for mask in range(1<<len(xs)):
        yield tuple(x for i,x in enumerate(xs) if mask>>i&1)

def rank(F,A,n): return len(rref(F,A,n)[0])
def pow_list(F,a,n): return [F.pow(a,i) for i in range(n)]

def audit(name,F,n,k,lam,roots1,roots2,m):
    lamstar=F.inv(F.frob(lam,k))
    # Verify factor roots and the exact inverse semilinear-reciprocal maps.
    assert all(F.pow(r,n)==lam for r in roots1)
    assert all(F.pow(r,n)==lamstar for r in roots2)
    assert len(set(roots1))==len(set(roots2))==n
    assert poly_product(F,roots1)==(lam,)+(0,)*(n-1)+(1,)
    assert poly_product(F,roots2)==(lamstar,)+(0,)*(n-1)+(1,)
    rho=(F.m-k)%F.m
    tauR={r:F.inv(F.frob(r,rho)) for r in roots2}
    tauL={r:F.inv(F.frob(r,k)) for r in roots1}
    assert set(tauR.values())==set(roots1) and set(tauL.values())==set(roots2)
    assert all(tauL[tauR[r]]==r for r in roots2)
    assert all(tauR[tauL[r]]==r for r in roots1)
    C1=[];C2=[]
    for J in subsets(roots1):
        C=code_from_generator(F,poly_product(F,J),n,lam)
        assert is_shift_invariant(F,C,lam,n)
        C1.append((J,C))
    for J in subsets(roots2):
        C=code_from_generator(F,poly_product(F,J),n,lamstar)
        assert is_shift_invariant(F,C,lamstar,n)
        C2.append((J,C))
    checked=0
    for J1,A in C1:
        dl=left_dual(F,A,k,n)
        assert is_shift_invariant(F,dl,lamstar,n)
        for J2,B in C2:
            dr=right_dual(F,B,k,n)
            assert is_shift_invariant(F,dr,lam,n)
            hr=intersection_dimension(F,A,dr,n)
            hl=intersection_dimension(F,B,dl,n)
            # Matrix of the restricted sesquilinear form on bases of B x A.
            G=[]
            for b in B:
                row=[]
                for a in A:
                    z=0
                    for bi,ai in zip(b,a): z=F.add(z,F.mul(bi,F.frob(ai,k)))
                    row.append(z)
                G.append(tuple(row))
            cr=rank(F,G,len(A))
            assert cr==len(A)-hr==len(B)-hl,(name,J1,J2,cr,hr,hl)
            assert (m*len(A))==(m*hr+m*cr)
            checked+=1
    assert checked==64
    print(f'{name}: {checked} code pairs; {len(roots1)} reciprocal factors; right/left dual shifts, inverse factor maps, radicals, and coupling rank verified')

if __name__=='__main__':
    F4=BinaryField(2,0b111)
    audit('F4 cyclic split example',F4,3,1,1,(1,2,3),(1,2,3),1)
    F16=BinaryField(4,0b10011);alpha=2
    lam=F16.pow(alpha,3)
    roots_lam=tuple(F16.pow(alpha,e) for e in (1,6,11))
    roots_star=tuple(F16.pow(alpha,e) for e in (3,8,13))
    audit('N2-B F16 incompatible-twist example',F16,3,1,lam,roots_lam,roots_star,2)
