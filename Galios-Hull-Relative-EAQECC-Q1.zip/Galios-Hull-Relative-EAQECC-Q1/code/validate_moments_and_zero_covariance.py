#!/usr/bin/env python3
"""Exact exhaustive moment, covariance, and zero-pattern audits on short cycles."""
from fractions import Fraction
from orbit_model import orbit_stats, count_zero_patterns

for a in range(1,7):
    rows,mu,cov=orbit_stats(a)
    assert mu[0]==mu[1]==Fraction(a,4)
    assert cov(0,0)==Fraction(3*a,16)
    target= -Fraction(1,16) if a==1 else (-Fraction(1,8) if a==2 else -Fraction(a,8))
    assert cov(0,1)==target,(a,cov(0,1),target)
    assert cov(0,2)==cov(0,3)==0
    assert count_zero_patterns(a)==2**__import__('math').gcd(a,2)
    assert count_zero_patterns(a,True)==2
    print(f'a={a}: mean={mu[0]}, var={cov(0,0)}, cross={cov(0,1)}, cov(H12,H1)=0')
print('One-sided zero pairs: 3^F by edge independence; mutual LCD and LCP cycle counts verified.')
