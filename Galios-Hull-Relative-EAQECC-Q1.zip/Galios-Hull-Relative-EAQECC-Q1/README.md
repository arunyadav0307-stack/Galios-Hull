# Relative hulls and paired-modulus EAQECCs

This package contains the complete LaTeX source and compiled PDF for the paper, its BibTeX bibliography, five exact-arithmetic validation programs with their supporting modules, the build/validation scripts, captured outputs, and a journal-submission checklist.

## Manuscript

- `manuscript/main.pdf` is the final **23-page** paper. It was built with Tectonic 0.17.0 and automatic BibTeX processing; the final build completed with zero errors and zero warnings.
- `manuscript/main.tex` is the complete source and includes five TikZ figures and eight LaTeX table environments (five principal data/coverage tables plus three compact supporting tables).
- `manuscript/references.bib` has 21 records: 20 published works and one clearly identified unpublished Phase-10F baseline cited by the manuscript.
- The Q1 submission checklist is in `SUBMISSION_CHECKLIST.md` and includes the MSC 2020 codes, keywords, cover-letter points, upload guidance, and remaining author/journal checks.

## Rebuild

From this directory, run:

```sh
bash tools/build_pdf.sh
```

The script uses `pdflatex` plus `bibtex` if both are installed; otherwise it uses the cached Tectonic 0.17.0 binary and bundle at `/tmp/tex-build`. The build script performs the required TeX/BibTeX passes and fails if it detects warnings, errors, or unresolved references. The submitted PDF was separately rendered and visually reviewed page-by-page.

## Re-run validations

```sh
bash tools/run_all_validations.sh
```

All five programs use exact arithmetic over `GF(4)=GF(2)[omega]/(omega^2+omega+1)` and `GF(16)=GF(2)[alpha]/(alpha^4+alpha+1)`. The two `finite_field_audit.py` and `orbit_model.py` files are required support modules; the five `validate_*.py` files are the runnable audits. Each captured output is included under `validation/`.

## Principal verified results

- For `GF(4)`, length 5 and twist `omega`, all seven nonzero constacyclic codes have exact standard-Hamming distances; all are MDS/EA-MDS. All eight LCP cases were distance-checked.
- For `GF(16)`, length 3 and twists `alpha^3` and `alpha^9`, all seven nonzero codes per twist and all 49 ordered paired-modulus cases were enumerated. Exact normalizer-set distances and EA Singleton checks were made in each applicable paired case.
- The paired CSS convention uses `C2` as the X-check space and `C1` as the Z-check space. The logical dimension is `k_Q=n-K1-K2+c` for the stated directional pairing rank; the inconsistent alternative `K1+K2-n+c` is not used. Multi-component scalar quantum distances are not asserted without a specified coordinate expansion/projection isometry and quantum construction.
- The exhaustive mixed-algebra examples cover 65,536 ordered G1 pairs and 4,096 G2 pairs. The corrected G1 factorization is `x^5-omega=(x+omega^2)(x^2+x+omega)(x^2+omega*x+omega)`; G1's `GF(16)` orbit weights are `[2,2]`.

See `validation/VALIDATION_SUMMARY.md` for the validation map and detailed finite test coverage. The checksums for all files other than this manifest are in `MANIFEST.txt`.
