# Q1 journal submission checklist

## Manuscript package

- [ ] Confirm target journal scope, manuscript template, page/word limits, reference style, and submission portal requirements.
- [ ] Replace the blank author line in `manuscript/main.tex`; verify author names, affiliations, corresponding-author email, ORCID identifiers, and acknowledgments.
- [ ] Confirm whether the journal uses single- or double-blind review. If double-blind, prepare a separate anonymized PDF/source and remove identifying metadata from acknowledgments and file properties.
- [x] Main manuscript PDF and editable LaTeX source: `manuscript/main.pdf`, `manuscript/main.tex`.
- [x] Bibliography source: `manuscript/references.bib`; citations compile with no unresolved entries.
- [x] Mathematical appendices/examples and embedded figures/tables are included in the manuscript source. No external figure assets are required.
- [x] Reproducibility README, exact-arithmetic validation code, captured validation outputs, build log, checksums, and page audit are included in this package.
- [ ] Prepare a journal-formatted title page and any required graphical abstract/highlights (not currently included).
- [ ] Add funding statement, conflict-of-interest statement, author-contribution statement, and data/code availability declarations as required by the selected journal. Current data statement says no external datasets are required; authors should confirm the code-release terms.
- [ ] Check permissions for any reused material (none is intentionally reproduced in the current manuscript) and complete any journal-specific ethics forms.
- [ ] Run the target journal's final PDF/preflight check after applying its template.

## Mathematics and claims requiring author sign-off

- [x] Single-field Hamming distances are computed directly in the field coordinate alphabet; no Gray map is used for those examples.
- [x] The N2-B benchmark exhausts all 49 nonzero paired-modulus code pairs over GF(16), including exact EA-CSS normalizer-set distances and Singleton checks.
- [x] The supplied two-code logical-dimension expression `K1 + K2 - n + c_k` is not used: with full/full codes at `n=3`, `K1=K2=c_k=3` it gives 6 logical symbols on 3 coordinates. The manuscript states the rank-consistent CSS formula `n - K1 - K2 + c_k` for the stated check-space orientation and excludes stabilizer vectors in the exact distance.
- [x] LCP distances are stated as `min(d_H(C1), d_H(C2^{perp_R}))` for the single-field standard Hamming metric.
- [x] For the product algebra `F4 x F16`, no scalar quantum Hamming distance is claimed without selecting a specific `F4`-linear projection/Gray isometry and its metric.
- [ ] Authors should independently review the EA stabilizer convention, left/right Galois-dual orientation, logical-distance quotient sets, and the correction of the supplied sign before journal submission.
- [ ] Verify every bibliographic record, DOI, author spelling, and publication status against the journal's preferred citation format.

## MSC 2020 classifications

- `94B05` — Linear codes, general theory.
- `94B15` — Bounds on codes.
- `81P70` — Quantum information, communication, and computation.
- `11T71` — Algebraic coding theory; finite fields and applications.
- `05A15` — Exact enumeration problems, generating functions.

## Keywords

Constacyclic codes; Galois duality; Galois hulls; paired-modulus duality; relative hulls; linear complementary pairs; entanglement-assisted quantum error-correcting codes; transfer matrices; exact enumeration; finite fields.

## Cover-letter points to adapt to the target journal

- The manuscript develops a contravariant duality between constacyclic codes over adjoint paired moduli, including incompatible twists.
- It gives exact factorwise enumerators for two directed relative hulls and restricted-pairing rank, plus a compatible-twist transfer trace and parity reduction.
- It derives orbit moments, covariance and zero-count formulas, and exact single-field Hamming/EA/LCP examples.
- It supplies dependency-free exact-arithmetic validators that exhaustively check 65,536 mixed-algebra pairs and 4,096 paired-modulus pairs, together with smaller all-codeword-distance audits.
- It is explicit about scope: quantum distances on a single field component use the standard Hamming metric, while a product-algebra scalar distance requires an explicitly chosen coordinate projection.

## Final pre-upload checks

- [ ] Rebuild using the target journal's TeX class and ensure no warnings or unresolved references.
- [ ] Re-run `bash tools/run_all_validations.sh` and retain the captured output.
- [ ] Compare the submission PDF against the final source, especially the paired-EA sign convention and all distance tables.
- [ ] Upload the journal-requested subset only; retain `MANIFEST.txt`, `traceability/SHA256SUMS`, and the Phase-3 audit as internal provenance or supplementary files as appropriate.
