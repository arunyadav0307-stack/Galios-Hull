# Galios-Hull — Final Paper Source Package (current commit dfe1995)

Source commit: `dfe1995d4b74c947df8c36b9d1f6d905a7d1660b` on branch `arena/ab8e330d-galios-hull`.
This package refreshes the paper package for the current manuscript after the
cloud-audit fixes (corrected Example 9.4, new Example 9.6, current author
details). It supersedes the earlier package built for commit ea18e8c.

## Main source
- `manuscript/P1_15_MANUSCRIPT_DRAFT.tex` — version of record.
  SHA-256: `89e277a5b659b6ecad88573b7498f441645c7a3864542e52b403e8059dba2102`
- `manuscript/P1_15_MANUSCRIPT_DRAFT.md` — synchronized Markdown companion.
  SHA-256: `1227d068a3cd9bed030aada736ffbc24b46074db56b6c85bff6a97339321a931`
- `manuscript/references.bib` — standalone BibTeX form of the 18 cited
  references. The `.tex` uses an inline `thebibliography`, so BibTeX is not
  needed to compile the source as supplied.

Author as supplied: Arun Kumar Yadav, School of Basic and Applied Sciences,
K.R. Mangalam University, Gurugram, arunyadav0307@gmail.com.

## Compile (author-side TeX system required)
From the extracted package root:

```bash
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error P1_15_MANUSCRIPT_DRAFT.tex
pdflatex -interaction=nonstopmode -halt-on-error P1_15_MANUSCRIPT_DRAFT.tex
```

Required packages are only the standard `article` class with `geometry`,
`amsmath`, `amssymb`, and `amsthm`.

**Compilation status:** not compiled in the preparation environment because
no TeX compiler is available. No compiled manuscript PDF and no preview PDF
is included. Compilation and visual proofreading remain pending; after
compiling, return the complete `.log` and generated `.pdf` for the
layout/error review before calling any PDF final.

## Contents
- `code/` — validator programs and saved outputs, including
  `validate_p1_14.py`, `validate_p1_20.py`, `validate_code_table.py`, and
  `validate_audit_fixes.py` with `validation_audit_fixes_output.txt`.
- `supporting_records/` — theorem blueprint (frozen), proof records,
  independent/proof audits, correction notes, adoption record, L1-closure
  record, and the cloud-audit fix log.
- `MANIFEST_SHA256.txt` — SHA-256 manifest for every packaged file except
  the manifest itself. Verify after extraction with:
  `sha256sum -c MANIFEST_SHA256.txt` from the package root.

## Validation summary
- Example 9.4 correction independently checked: dimension is invariant
  under predecessor/successor reversal; the orientation check is at the
  \(h^\#\) exponent level, with predecessor \(2187/2187\) and successor
  \(27/2187\) in the GF(8) case (`code/validate_audit_fixes.py`).
- The ten EAQECC table rows remain verified by
  `code/validate_code_table.py` (`ALL 10 CODE-TABLE ROWS VERIFIED`).
- Existing validators were rerun in P1-30/P1-31 checks; recorded outputs are
  packaged. Finite computations are supporting evidence, not substitutes
  for the proofs.

## Remaining blockers / status
- LaTeX compilation and PDF visual proofreading: pending author-side compile.
- Gate G1 remains DEFERRED: no novelty or priority claim is made. The 2023
  related paper has not been compared at theorem level from a lawfully read
  full text.
- Journal-submission artefacts (target journal, cover letter, declarations,
  code/data DOI, ORCID/anonymised copy if required) remain author-side items.
